// JavaScript Document
var initContent;
var initCircleContent;
var rtime = new Date(1, 1, 2000, 12,00,00);
var timeout = false;
var delta = 200;

$(document).ready(function(){ 
	initContent = $('body').html();
	initCircleContent = $('#listCircle').html();
	
});

$(window).resize(function() { rezizeEventFunction();});



function manageCarrousel(){	
	var totImages = $('ul.carrousel li img').length;
	addControl('manageCarrousel' + totImages);
	var imgsLoaded = 0;
	$('ul.carrousel li img').each(function(index){
		var image = new Image();
		image.onload = function () {
		   addControl("Image loaded !");
		    imgsLoaded++;		 
		  if(imgsLoaded>=totImages){
			  addControl("All Image loaded !" + imgsLoaded);
			  startCarrolusel();
			}
		}
		image.onerror = function () {
		   console.error("Cannot load image");
		   //do something else...
		}
		image.src = $(this).attr('src');
		
	});
}
	
function startCarrolusel(){	
	var h = 0;
	var w = 0;
	var itemWidth = $('.carrouselContainer').width();
	$('ul.carrousel li').each(function(index){
		$(this).css({
			position:'absolute',
			left:0,
			'z-index':0,
			width:itemWidth,
			left:0,
			left:(itemWidth*index)
		}) 
		var objH = $(this).outerHeight(true);;
		if(h<objH){h=objH};
		$(this).find('img').css({position:'absolute','z-index':-1,top:0,left:0});		 
		w += $(this).outerWidth(true);
	});	
	$('ul.carrousel,.carrouselContainer,ul.carrousel li').css({
		'height':h+'px'
	});
	$('ul.carrousel').css({
		'width': w+'px'
	});
	//$('.carrouselContainer').append('<div id="prevCarrousel" style="left:0"/></div><div id="nextCarrousel" style="right:0"/></div>');
	var pos=0;
	if($('.carrouselContainer').attr('data-pos')){pos = $('.carrouselContainer').attr('data-pos');}
	$('.carrouselContainer').attr('data-pos',pos-1);
	$('#prevCarrousel').css({background:"url(../src/images/prevCarrousel.png)"});
	$('#nextCarrousel').css({background:"url(../src/images/nextCarrousel.png)"});
	$('#prevCarrousel,#nextCarrousel').css({
		'background-repeat':'no-repeat',
		'background-position':'center',
		'background-color':'rgba(0, 0, 0, 0.5)',
		width:'50px',
		height: h+'px',
		position:'absolute',
		'z-index':2	,	
		'cursor':'pointer'
	})	
	$('#activePage').remove();
	$('.carrouselContainer').append('<ul id="activePage" style="position:absolute;bottom:0px;list-style:none;margin:5px"></ul>');
	$('ul.carrousel li').each(function(index){
		$('#activePage').append('<li class="activePage">'+index+'</li>');
	});
	$(document).off('click', '#activePage li').on('click', '#activePage li',function(){		
		 $('.carrouselContainer').attr('data-pos',$(this).index()-1);
		 $('#nextCarrousel').click();
	});
	$('#activePage').css({
		left:-$('#activePage').outerWidth(true)/2,
		'margin-left':'50%'
	})
	$(document).off('click', '#prevCarrousel,#nextCarrousel').on('click', '#prevCarrousel,#nextCarrousel',function() { 
		 clickCarrousel($(this));
	});
	$('#nextCarrousel').click();
	
}

function clickCarrousel(obj){
	var pos = parseInt($('.carrouselContainer').attr('data-pos'));
	$('#activePage li').removeClass('activePageOn');
	
	if(obj.attr('id')=='prevCarrousel'){
		if(pos>0){moveCarrousel(pos-1);
		}else{
			$('#prevcarrousel').css('opacity','0.5')
		}
		$('#activePage li').eq(pos-1).addClass('activePageOn');
		return true
	}
	if(pos<$('ul.carrousel li').length-1){moveCarrousel(pos+1);}
	$('#activePage li').eq(pos+1).addClass('activePageOn');
}

function moveCarrousel(pos){
	$('.carrouselContainer').attr('data-pos',pos);
	$('ul.carrousel').animate({
		'left':($('ul.carrousel li').width())*(-pos)
	  }, 1000, function() {
   		 // Animation complete.
 	 });
	
}


function rezizeEventFunction(){
	rtime = new Date();
    if (timeout === false) {
        timeout = true;
        setTimeout(resizeend, delta);
    }
}

function resizeend() {
    if (new Date() - rtime < delta) {
        setTimeout(resizeend, delta);
    } else {
        timeout = false;
		//setTimeout(function(){  }, 1000);
		startCarrolusel();
		if($('.mapa_imagen').length>0){
			colocaImgZones();			
		}
		if($('.listLetterAnim').length>0){
			$('.listLetterAnim').each(function(index){
				positionateListSlideShow($(this));							   
			});	
		}		
		if(resizeScaleContent){
			recolocaScaleAnimation();
		}		
		centerCircleDiv(1);
    }               
}
/**************************************************************************************////
function initAnims(){
	listItemNum = 0;
	letterPos = 0;
	listPage = 0;	
	listAnimation();
	listSlideShow(); 
	liScaleAnimation();	
	//liEsquemaAnimation(true);
	createCircle();
	animVertical();
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
////ANIMACIÖN DE LISTA //////////////////////////////////////////////////////////////////////////////////////////////*/

var posyList = new Array();
var posxList = new Array();

function listAnimation(){
	posyList = new Array();	
	if(!$('.listAnimUl').length){		
		$('.listAnim').each(function(){										
			var listObj = $(this).find('#listAnimUlBase').clone().appendTo($(this));
			listObj.attr('class','listAnimUl');
			listObj.attr('id','');
			listObj.removeClass('listSequence');
			listObj.css({
				position:'absolute',
				display:'block',
				float:'left',
				top:0
			});
			 $(this).find('#listAnimUlBase').css('visibility','hidden');
		 });		
	}	
	//calculatePercent()
	if($('.listAnim').length){
		$('.listAnim').each(function(){		
			var objY = 0;
			var listAnim = $(this);		
			var listUl = listAnim.find('.listAnimUl');							
				listUl.find('li').each(function(index){
					var objListLi = $(this);
					 objY = 0;
					if(index>0){
						var preObj = $(this).parent('ul').find('li:eq('+(index-1)+')');
						objY = preObj.position().top + preObj.outerHeight(true); 
						//addControl(preObj.attr('class') + ' objY:' + preObj.position().top);
						//addControl(index + ' objY : ' + objY)
					}else{}
					posyList.push(objY)
					objListLi.attr('x',$(this).position().left);
					objListLi.attr('y',objY);
					objListLi.css({
							position:'absolute',
							margin:$('#listAnimUlBase li').css('margin'),
							padding:$('#listAnimUlBase li').css('padding'),
							top:objY
						});
				});	
				
			setListAnimPosition(listUl);
			if(listAnim.attr('action')=='on'){
				animateList(0,listAnim);
			}else{
				listAnim.css('background-image','url(../images/recursos/botAnimMas.png)');
				listAnim.css('background-position','center');	
				listAnim.css('background-repeat','no-repeat');
				listAnim.css('background-repeat','no-repeat');
				listAnim.css('cursor','pointer');
				listAnim.on('click',function() { 			
					$(this).css({
						'background-image':'none',
						cursor :'auto'
					});
					$(this).click(function(){return false;});
					animateList(0,$(this));
				});	
			}
		});
		$('.caja').css('visibility','visible');
		$('.caja').css('overflow','hidden');
	}
}


function setListAnimPosition(listActv){
	//addControl("setListAnimPosition : " + typeof listActv)
	listActv.find('li').each(function(index){
				var objListLi = $(this);
					if(objListLi.hasClass('animTop')){
						objListLi.css({
							position:'absolute',
							top : - $('body').outerHeight(true),
							left:0,
							margin:$('#listAnimUlBase li').css('margin'),
							padding:$('#listAnimUlBase li').css('padding'),
							visibility :'hidden'
						});
					}
					if(objListLi.hasClass('animLeft')){
						objListLi.css({
							position:'absolute',
							left : - $(window).width()-100,
							top : $(this).attr('y'),
							margin:$('#listAnimUlBase li').css('margin'),
							padding:$('#listAnimUlBase li').css('padding'),
							visibility :'hidden'
						});
					}
					if(objListLi.hasClass('animRight')){
						objListLi.css({
							position:'absolute',
							left : $('body').outerWidth() + 100,
							top : $(this).attr('y'),
							margin:$('#listAnimUlBase li').css('margin'),
							padding:$('#listAnimUlBase li').css('padding'),
							visibility :'hidden'
						});
					}
					if(objListLi.hasClass('animBottom')){
						objListLi.css({
							position:'absolute',
							top : $(window).height()+ 100,
							left:0,
							margin:$('#listAnimUlBase li').css('margin'),
							padding:$('#listAnimUlBase li').css('padding'),
							visibility :'hidden'
						});
					}
				});	
}

var listItemNum = 0;
function animateList(pos,listAnim){	
	//addControl('animateList' + pos +' - ' + listAnim)
	listAnim.css('background-image','none');
	if(!pos){pos=0;}	
	_obj = listAnim.find('.listAnimUl > li').eq(pos);
	_obj.css('visibility','visible');
	_obj.animate({
			left: 0,
			top: _obj.attr('y')
		},500,function(){
			pos++;
			if(pos<listAnim.find('.listAnimUl > li').length){
				animateList(pos,listAnim);
			}else{
				var reiniciar = listAnim.find('.reiniciar');
				if(reiniciar.length<=0){
					listAnim.append('<p style="float:right;" margin:20px 0;><a href="javascript:void(0)" class="reiniciar">Reiniciar</a></p>');																							   					reiniciar = listAnim.find('.reiniciar');
					reiniciar.on( "click", function( event ) {				
								_obj = $(this).parent().parent().find('.listAnimUl');
								addControl('REINICIO' + typeof _obj);								
								setListAnimPosition(_obj);
								_obj = $(this).parent().parent().parent().find('.listAnim');
								animateList(0,_obj);
								$(this).remove();
					});
				}
			}
	});
}


/*////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
/*///ANIMACIÖN LISTA ALFANUMERICA CARROUSEL /////////////////////////////////////////////////////////////////////////////////////*/

var letterPos = 0;
var highestListSlideDiv = 0;
function listSlideShow(){
	$('.listLetterAnim').each(function(indexA){
			var objLisLetter = $(this);	
			objLisLetter.css({visibility:'hidden'});
			highestListSlideDiv = 0;
			objLisLetter.find(' > li').each(function(index){
				var objLi = $(this);
				var txt = objLi.html();
				objLi.empty();
				objLi.append('<div class="listLetterDiv"><div class="letterBig"></div><div class="letterTxt"></div></div>');
				var contador = letrasArr[index];
				//alert($(this).parent().parent().attr('action'))
				if($(this).parent().parent().attr('action')=='numbers'){
					contador = index+1;
				}
				objLi.find('.letterBig').append(contador);
				objLi.find('.letterTxt').append(txt);
				if($(this).parent().parent().attr('action')=='img'){					
					objLi.find('.letterBig').empty().append('<img style="height:auto" src="'+$(this).parent().parent().attr('data-img')+'"/>');
				}
			});	
			//add controls
			var controles = '<div class="controls"><a class="listPrev" onClick="listAnimationNext(false,$(this).parent().parent().find('+"'ul'"+'));" title="anterior" style="margin-right:5%;"><img src="../images/recursos/botPrev.png" alt="anterior"/></a><a class="listNext" onClick="listAnimationNext(true,$(this).parent().parent().find('+"'ul'"+'));" title="siguiente" style="margin-left:5%;"><img src="../images/recursos/botNext.png" alt="siguiente"/></a></div>';
			objLisLetter.parent().append(controles);
			$('.controls').css({opacity:0});
			var ancho = objLisLetter.parent().attr('data-width');
			if(ancho != undefined){
				objLisLetter.find('.letterBig').css({width:ancho});	
			}
			setTimeout(function(){
				objLisLetter.find(' > li').each(function(index){
					var objLi = $(this);
					var high = objLi.find('.listLetterDiv').outerHeight(true);
					if(high > highestListSlideDiv){
						highestListSlideDiv = high;
					}									 
				});
				var alto = objLisLetter.parent().attr('data-height');
				if(alto>highestListSlideDiv){
					highestListSlideDiv = alto;	
				}
				objLisLetter.css({height:highestListSlideDiv,opacity:0,visibility:'visible'});
				objLisLetter.animate({opacity:1}, 1000, function(){});
				if(typeof audioTextChangeTime1 == 'undefined'){
					$('.controls').animate({opacity:1}, 1000, function(){});
				}
				positionateListSlideShow(objLisLetter);
			}, 500);
		})
}

function positionateListSlideShow(objLisLetter){
	var highestListSlideDiv = 0;
	objLisLetter.attr('data-listPage',0);
	objLisLetter.css({height:'auto',visibility:'hidden'});
	objLisLetter.find('> li').each(function(index){
		var objLi = $(this);
		var high = objLi.find('.listLetterDiv').outerHeight(true);
		if(high > highestListSlideDiv){
			highestListSlideDiv = high;
		}									 
		objLi.css({
			position:'absolute',
			left: (objLi.outerWidth(true) * (index)),
			visibility:'visible'
		});
		var alto = objLisLetter.parent().attr('data-height');
		if(alto>highestListSlideDiv){
			highestListSlideDiv = alto;	
		}
		objLisLetter.css({height:highestListSlideDiv,visibility:'visible'});	
	});
	objLisLetter.animate({
		left: 0
		},500,function(){});
		manageListSlideShowControls(objLisLetter);	
	return true;
}

function calculatePercent(obj,container){
	var tH = container.innerHeight();
	var tW = container.innerWidth();
	var H = obj.outerHeight(true);
	var W = obj.outerHeight(true);
	var percentW = (W*100)/tW;
	var percentH = (H*100)/tH;
	//alert(percentW)
	return percentW;
}



var listPage = 0;
function listAnimationNext(pos,objLisLetter){	
	var listPage = parseInt(objLisLetter.attr('data-listPage'));
	//addControl('listPage: ' +typeof listPage + ' : ' + listPage);
	if(pos){
		dir = '-=';
		objLisLetter.attr('data-listPage',listPage +1 );
	}else{
		dir = '+=';
		objLisLetter.attr('data-listPage',listPage -1);
		}
	objLisLetter.animate({
			position:'absolute',
			left: dir + objLisLetter.find('li').outerWidth(true)
	},500,function(){});
	manageListSlideShowControls(objLisLetter);	
}

function manageListSlideShowControls(objLisLetter){
	var listPage = parseInt(objLisLetter.attr('data-listPage'));
	objLisLetter.parent().find('.controls').find('a').css({visibility:'visible'});
	objLisLetter.parent().find('.controls').find('a:eq(0)').css({width:'150px'});
	if(listPage<=0){
		objLisLetter.parent().find('.controls').find('a:eq(0)').css({visibility:'hidden'});
	}
	var total = objLisLetter.find('> li').not('li ul li').length;
	if(listPage >=total-1){
		objLisLetter.parent().find('.controls').find('a:eq(1)').css({visibility:'hidden'});
	}	
	//addControl('listPage:' + listPage + ' de ' + total);
}


/*////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
/*///ANIMACIÖN DE LISTA ESCALABLE ESQUEMAS//////////////////////////////////////////////////////////////////////////////////////////////*/

var scaleContent;
var resizeScaleContent = false;
function liScaleAnimation(_actv){	
	addControl('liScaleAnimation');
	$('.listEscalable').each(function(){									  
			var obj = $(this);						 
			var action = obj.attr('action');
			var type = obj.attr('type');
			var space = obj.attr('space');
			addControl('action : ' + action + ' type: ' + type + '  space : ' + space)
			if($(window).width()<500){
				obj.css('width','100%');
			}
			obj.find('li').each(function(index){											 
					var obj1 = $(this);	
					if(!space){
						obj1.find('div:first').css({
							margin: '1%',
							width:'98%',
							height:'98%',
							overflow: 'visible'
						});
					}else{
						if(obj1.find('div').height()>obj1.height()){
							obj1.find('div:first').css({height:obj1.height(),display:'block'});
						}
						obj1.css({overflow: 'hidden'});
					}
					if(obj1.parent().hasClass('lista_visible')){
					}else{
						obj1.css({visibility:'hidden'});
					}
			});
			
			if(action == "on" || _actv){		
				scaleContent = obj.html();
				if(type != 'step'){
					escaleAnimation(0,false,obj);
				}else{
					escaleAnimation(0,true,obj);
				}
				resizeScaleContent = true;
			}else{
				obj.css({						
					'background-image':'url(../images/recursos/botAnimMas.png)',
					'background-position':'center',	
					'background-repeat':'no-repeat',
					'background-repeat':'no-repeat',
					height:'50px',
					cursor:'pointer'
				});
				
				obj.on('click',function(event) { 
					$(this).css('background-image','none');
					$(this).css('cursor','auto');
					$(this).attr('onclick','').unbind('click');
					escaleAnimation(0,false,$(this));
				});	
			}
	});
}


function escaleAnimation(pos,type,obj){
	//addControl('escaleAnimation ' + pos + ' : ' + type + ' : ' + obj);

	if(isNaN(pos)){
		obj = pos;		
		pos = 0;
	}
	var obj1 = obj.find('li:eq('+pos+')');		
	if(obj.attr('type') == 'order'){
		 obj1 = obj.find('li[rel='+pos+']');
	}	
	obj.css('height','auto');
	if(obj.attr('type') == 'year'){		
		 obj1.find('div > div').css({padding:0});	
		 if(obj.parent().find('.listEscalablecont-'+pos).length>0){
			 obj1.css({cursor:'pointer'});	
			 obj1.click(function() {			
				obj.parent().find('div[class|="listEscalablecont"]').css('width', obj.width());
				obj.parent().find('div[class|="listEscalablecont"]').slideUp();
				obj.parent().find('.listEscalablecont-'+pos).slideDown();
				$( "div[id^='bloque']").slideUp( "fast", function() {});
			});
		 }
	}	
	var secs = parseInt(obj1.attr('secs'));
	if(isNaN(secs)){secs=500;}
	var delay = parseInt(obj1.attr('delay'));
	if(isNaN(delay)){delay=500;}
	var btnpos = obj1.attr('btnpos');	
	obj1.css({visibility:'visible',opacity:0});
	var totLi =  obj.find('> li').length-1;	
	if(totLi==-1){totLi  = obj.find('li').length-1;	}
	obj1.data( "pos", (totLi) - parseInt(pos+obj1.length));
	obj1.animate({		
				opacity:1
			},secs,function(){				
				addControl('POS: ' + pos + ' TOT LI : ' + totLi);				
				if(pos<=totLi && !type){	
					//addControl('anim 1:' + type)
					if(!delay){delay=0;}					
					setTimeout(function() {						
						addControl('dataPos:' +obj1.data( "pos"));
						//if((totLi)<=obj1.index()){
						if(obj1.data("pos")<=0){
							addControl('FIN ESCALE ANIM' + obj1.index());
							var reiniciar = obj.find('.reiniciar');
							if(reiniciar.length<=0){
								obj.append('<li style="width:100%;margin:20px; 0"><a href="javascript:void(0)" class="reiniciar">Reiniciar</a></li>');
								obj.find('.reiniciar').on( "click", function( event ) {
									obj.find('> li').css({
										visibility:'hidden'
									});
									obj.find('div[id*="bloque"]').css({
										display:'none'
									});
									$(this).parent('li').remove();
									escaleAnimation(0,false,obj);
								});
							}
							
						}
						var thePos = parseInt(pos+1);
						escaleAnimation(thePos,false,obj);
					}, delay);
				
				}
				if(type){
					addControl('Anim 2:' + type);
					if(!type){				
						obj.html(scaleContent);
					}else{
						var objNext = obj1.attr('rel');
						if(objNext){
							pos = objNext;
						}else{
							pos++;	
						}
						var action = obj.attr('action');
						if(pos < totLi ){
							var imgUrl = '../images/recursos/botNext.png';
							var btnNext = obj1.prepend('<a data-pos="'+pos+'" data-obj="'+obj+'" class="btnStep"><img src="'+imgUrl+'" width="30px" height="30px"/></a>');
							var bot;
							$('.btnStep').on( "click", function( event ) {
									bot = $(this);
									escaleAnimation(bot.attr('data-pos'),true,bot.parent().parent());
									bot.remove();
								});
							var btnW = obj1.find('.btnStep').outerWidth(true);
							var posL = obj1.position().left + obj.outerWidth(true)-btnW; 
							var posT = obj1.position().top + (obj.outerHeight(true)/2)-(btnW/2);
							if(btnpos=='top')	{posL = obj1.position().left + (obj1.outerWidth(true)/2)-(btnW/2); posT = obj1.position().top; imgUrl = '../images/recursos/botNextTop.png'};
							if(btnpos=='bottom'){posL = obj1.position().left + (obj1.outerWidth(true)/2)-(btnW/2); posT = obj1.position().top+(obj1.outerHeight(true))-(btnW); imgUrl = '../images/recursos/botNextBottom.png'};					
							if(btnpos=='right')	{posL = obj1.position().left;  posT = obj1.position().top+ ((obj1.outerHeight(true)/2)-(btnW/2)); imgUrl = '../images/recursos/botNext.png'};
							if(btnpos=='left')	{posL = obj1.position().left; posT = obj1.position().top + ((obj1.outerHeight(true)/2)-(btnW/2)); imgUrl = '../images/recursos/botPrev.png';					};
							if(action =="on"){
								posL = obj1.position().left + (obj1.outerWidth(true))-(btnW/2);  
								posT = obj1.position().top+ ((obj1.outerHeight(true))-(btnW/2)); 
								imgUrl = '../images/recursos/botAnimMas.png';
							}
							obj1.find('.btnStep img').attr('src',imgUrl);
							obj1.find('.btnStep').css({zindex:100,position:'absolute',left:posL,top:posT,width:'30px',height:'30px' });
						}else{
						//if(pos==totLi){
								addControl('FIN ESCALE ANIM TYPE');
								var reiniciar = obj.find('.reiniciar');
								if(reiniciar.length<=0){
									obj.parent().append('<p style="width:100%;margin:20px 0;float:left;" class="centrado"><a href="javascript:void(0)" class="reiniciar" style="float:none;height:30px;">Reiniciar</a></p>');
									obj.parent().find('.reiniciar').on( "click", function( event ) {
											addControl('REINICIO');
											obj.find('> li').css({
												visibility:'hidden'
											});
											obj.find('div[id*="bloque"]').css({
												display:'none'
											});
											$(this).remove();
											escaleAnimation(0,true,obj);
									});	
								}
							}
					}
				}		
	});
}

function nextScaleObj(pos,type,bot){
	//alert(bot.parent.parent.attr('class'))
	escaleAnimation(pos,type,obj);
	bot.remove();
}


function recolocaScaleAnimation(){
	$('.listEscalable').each(function(){									  
			var obj = $(this);						 
			if($(window).width()<500){
				//obj.css('width','100%')
			}
			obj.find('.btnStep').hide();
			obj.find('li').each(function(index){ 
					var obj1 = $(this);						 
					if(obj1.find('div:first').height()>obj1.height()){
						obj1.find('div:first').css({height:obj1.height()-(obj1.innerHeight()/100),display:'block'});
					}else{
						//obj1.find('div').css({height:'auto',display:'table'});
					}
					//obj1.css({overflow: 'hidden'});
					if(obj1.attr('rel') == obj1.find('.btnStep').attr('data-pos')){
						var btnW = obj1.find('.btnStep').outerWidth(true);
						var posL = obj1.position().left + (obj1.outerWidth(true))-(btnW/2); 
						var posT = obj1.position().top+(obj1.outerHeight(true))-(btnW/2);
						obj1.find('.btnStep').css({zindex:100,position:'absolute',left:posL,top:posT,width:'30px',height:'30px' });
						obj1.find('.btnStep').show();
					}
			});
			
	});	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
// Efecto circulo de elementos /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var circleRadius = 200;
function createCircle(){
	centerCircleDiv();
	$('#listCircle').css('visibility','visible');	
	roundCorners();
	$('#listCircle li').each(function(index) {
			if(index>0){
				var obj = $('#listCircle li:eq('+index+')');
				obj.addClass('listOff');
				obj.hover(
					 function () {
					   $(this).removeClass('listOff');
					   $(this).addClass('listOn');
					 }, 
					 function () {
						$(this).removeClass('listOn');
					   $(this).addClass('listOff');
					 }
				 );
				
				var secs = 1000*index;
				setTimeout(function() {
					showObj(obj);
					if(index>=$('#listCircle li').length-1){
						$('#listCircle li:eq(0)').show();
						setTimeout(function() {
							showObj($('.centerCircle'));
							$('.reiniciaCircle').show();
						}, 1000);
					}
				}, secs);
			}
	});	
	$('#listCircle li:eq(0)').find('div').each(function(){
				$(this).wrap( '<div style="display:table;"></div>' );
				$(this).css({display:'table-cell','vertical-align':'middle','text-align':'center'});
	});
	$('#listCircle li:eq(0)').find('div:eq(0)').show();
}


function centerCircleDiv(alpha){
	addControl('centerCircleDiv('+alpha+')');	
	if($('.centerCircle').length>0){
		if(!alpha){
			alpha = 0;
			$('#listCircle').css('visibility','hidden');
			$('.reiniciaCircle').hide();
		}
		$('.centerCircle').css('opacity',alpha);
		var fields = $('.circleField'), container = $('#listCircle'), width = container.width(), height = container.height();
		var angle = 180, step = (2*Math.PI) / fields.length;
		fields.each(function(index) {
			var x = Math.round(width/2 + circleRadius * Math.cos(angle) - $(this).width()/2);
			var y = Math.round(height/2 + circleRadius * Math.sin(angle) - $(this).height()/2);
			/*x = (x*100)/width;
			y = (y*100)/height;*/
			$(this).css({
				left: x + 'px',
				top: /*$('#listCircle').position().top* +*/ y + 'px',
				opacity:alpha
			});
			angle += step;
			$(this).click(function() {
				showObj($('.centerCircle'));
				$('.centerCircle > div').hide();
				$('.centerCircle > div:eq('+(index+1)+')').show();
			});	
		});
		var xpos = 50-(($('.centerCircle').width()/2)*100) / $('#listCircle').innerWidth();
		var ypos = 50-(($('.centerCircle').height()/2)*100) / $('#listCircle').innerHeight();
		$('.centerCircle').css({
				position:'absolute',
				left: xpos+'%',
				top: ypos+'%'
		});	
	}
}


var colocaImgZonesOn = false;
var mapImgRealW;
var mapImgRealH;
function colocaImgZones(){	
	addControl('#colocaImgZones#');	
	$('.mapa_imagen').css('visibility','hidden');
	var anchoVentana = $('window').width();
	$('body').find('.mapa_imagen').each(function(){
		var img = $(this).find('.images_escalable');
		var imgW = img.width();
		var imgH = img.height();
		var imgL = img.position().left;
		var imgT = img.position().top;
		if(!colocaImgZonesOn){
			 mapImgRealW = imgW;
			 mapImgRealH = imgH;			
		}
		if(!colocaImgZonesOn){
			 $(this).css({
				'width' :(mapImgRealW*100)/$('window').width()+'%'
			});
			 img.css({
				width: '100%',
				'max-width':imgW,
				'max-height':imgH,
				'z-index':-1
			});
			colocaImgZonesOn = true;
		}	
		var map = $(this).find('.mapa');		
		map.css({
				position :'absolute',			
				left:imgL,
				top:imgT,
				width: imgW,
				height: imgH,
				margin:0,
				padding:0,
				'z-index':0
		})
		map.find('li').each(function(){
				$(this).css({
					left: ($(this).position().left *100)/imgW +'%',
					top: ($(this).position().top *100)/imgH +'%',
					width: ($(this).position().left + $(this).width() *100)/imgW +'%',
					height: ($(this).height() *100)/imgH +'%'
				})							
		})
		map.css('max-width',img.css('max-width'));
		
	});
	$('.mapa_imagen').css('visibility','visible');
	//addControl('#mapImgRealW# : ' + mapImgRealW);
	//addControl('#mapImgRealH# : ' + mapImgRealH);
}


function animVertical(){
	$(".ocultar").hide();	
	for(i=0;i<10;i++){
		var index1 = 0;
		var max1 = $('.desplVert'+(i+1)+' > div').length;		
		var show = $('#show'+(i+1));
		show.attr('data-length', max1);
		show.attr('data-index', (i+1));
		show.attr('data-pos', 0 );		
		show.on('click', function() {
			var dataIndex = parseInt($(this).attr('data-index'));
			var dataLength = parseInt($(this).attr('data-length'));	
			var dataPos = parseInt($(this).attr('data-pos'));	
			//addControl(dataIndex + ' - ' +  dataLength + ' - ' + dataPos);	
			if (dataPos < dataLength){			
			   $('.desplVert'+dataIndex+' > div:eq('+ dataPos+')').show("slow");
			   var nextElem = parseInt(dataPos+1);
			  // addControl(nextElem + ' : ' + dataLength);
				$(this).attr('data-pos',nextElem);
			}
			if(dataPos >= dataLength-1){ $(this).hide();}
		})
	}
	
}
