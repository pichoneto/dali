//	JavaScript Document
//	Luis Miguel del Corral
//	Version:	1.0
//	Fecha:	21 Junio 2016
/*
	Datos:	Se eliminan consolas innecesarias a d�a de hoy

*/

var totalSteps = 0;;
var activeStep = 0;

var simulationFilesArr = new Array();
var stepsTitlesArr = new Array();
var stepsResponsesArr = new Array();
var stepsNotes = new Array();

$(document).ready(function() {
    $('#resultados').hide();
    loadSimulation();
});

function loadSimulation() {
    rutaXml = simulador
    $.ajax({
        type: "GET",
        url: rutaXml,
        dataType: "xml",
        success: function(xml) {
            $(xml).find("ITEMS").each(function(index) {
                NotaCorte = $(this).attr('notaCorte');
            });
            $(xml).find("TITLE").each(function(index) {
                stepsTitlesArr.push($(this).text())
            });
            $(xml).find("INTERACTION").each(function(index) {
                var value = "";
                totalSteps++;
                var total = $(this).find('FILE').length;
                $(this).find('FILE').each(function(index) {
                    value += $(this).text();
                    if (index < total && index > 0) {
                        value += ',';
                    }
                })
                simulationFilesArr.push(value);
                $('#step').append('<li class="step greySim rounded">' + index + '</li>')
            });

            var initFile = simulationFilesArr[0];
            loadSimContent(initFile);

        },
        error: function(xml) {
            alert("error carga xml:" + rutaXml)
        }
    });


}

function loadSimContent(_file) {
    simuladorTries = 0;
    var num = Math.floor((Math.random() * 1000) + 1);
    $("#simulador").load('simulador/' + _file + '?' + num, function(response, status, xhr) {
        if (status == "error") {
            var msg = "Sorry but there was an error: ";
            alert(_file + ' : ' + msg + xhr.status + " " + xhr.statusText);
        } else {
            if (typeof videoSimFiles != "undefined") {
                loadSimVideo();
            }
            $('.pastilla').hide();
            $('.situacionTitle').html('<b>' + (activeStep + 1) + '</b> - ' + stepsTitlesArr[activeStep]);
            $('.pastilla').css('overflow', 'hidden');
            $('.pastilla:eq(0)').slideDown('slow');
            $('#step li').removeClass('activeStep');
            var stepState = $('#step').find('li:eq(' + activeStep + ')');
            stepState.addClass('activeStep');
            showDiv('desdeJs');
            $('.caja').css('visibility', 'visible');
            hidePreloader();
        }
    });
}

function loadSimVideo() {
    if (typeof videoSimFiles != 'undefined') {
        for (i = 0; i < videoSimFiles.length; i++) {
            loadVideoContent(ruta + videoSimFiles[i], 'videoSimDiv' + i);
            $('#videoSimDiv' + i).css({
                visibility: 'visible'
            });
        }
    }
}

function showConsequence(pos, isOk) {
    stopVideos();
    var stepState = $('#step').find('li:eq(' + activeStep + ')');
    stepState.removeClass('greySim');
    stepState.removeClass('verdeoscuro');
    stepState.removeClass('rojo');
    stepState.removeClass('activeStep');
    simuladorTries++;
    if (isOk) {
        stepState.addClass('verdeoscuro');
        setStepResponse(1);
        if (simuladorTries == 2) {
            $('.pastilla:eq(2)').append('<p style="font-size:1.1em;float:left;margin:0 14%;color:red;">Lo has hecho bien en el intento 2 por lo que la puntuaci&oacute;n de esta situaci&oacute;n es la mitad de su valor.</p>');
            stepState.removeClass('verdeoscuro');
            stepState.addClass('azulverdoso');
        }
        if (simuladorTries == 3) {
            $('.pastilla:eq(2)').append('<p style="font-size:1.1em;float:left;margin:0 14%;color:red;">Lo has hecho bien en el &uacute;ltimo intento por lo que la puntuaci&oacute;n de esta situaci&oacute;n es de 0 puntos.</p>');
            stepState.removeClass('verdeoscuro');
            stepState.addClass('rojo');
        }
    } else {
        if (isOk == false) {
            setStepResponse(2);
            stepState.addClass('azulverdoso');
            showCorrectOne(true);
        } else {
            stepState.addClass('rojo');
            setStepResponse(0);
        }
    }
    roundCorners();
    $('div[id^=consecuencia]').css('display', 'none');
    $('#consecuencia' + pos).css('display', 'block');
    $('.pastilla:eq(1)').slideUp('slow');
    $('.pastilla:eq(2)').slideDown('slow');
}

function setStepResponse(val, end) {
    stopVideos();
    var val2 = val;
    if (simuladorTries == 2) {
        val = 2;
    };
    if (simuladorTries == 3) {
        val = 0;
    };
    if (simuladorTries <= simuladorIntentos && !end) {
        if (typeof stepsResponsesArr[activeStep] == 'undefined') {
            stepsResponsesArr[activeStep] = val;
        } else {
            stepsResponsesArr[activeStep] = stepsResponsesArr[activeStep] + ',' + val;
        }
    } else {
        stepsResponsesArr[activeStep] = stepsResponsesArr[activeStep] + ',' + val;
        if (val2 != 1) {
            showCorrectOne();
        }
        if (val2 == 0) {
            $('input').remove();
            showResults();
        }
    }
}

function showCorrectOne(ok) {
    var txt = "No lo has hecho bien. La respuesta correcta es:";
    if (ok) {
        txt = "Lo has hecho bien aunque la respuesta m&aacute;s correcta es:"
    }
    $('.pastilla:eq(2)').append('<p style="float:left;margin-left:14%;">' + txt + '</p>');
    var theOk = $('#ok').clone();
    theOk.find('input').remove();
    $('.pastilla:eq(2)').append(theOk.removeClass('opcion').addClass('consecuencia'));
}

function showResults() {
    $('#step').slideUp('slow');
    var txt = "";
    var respuestasOkArr = new Array();
    var interArr = new Array();
    var nota = 0;
    for (i = 0; i < totalSteps; i++) {
        var ok = 0;
        var resp;
        if (typeof stepsResponsesArr[i] != 'undefined') {
            if (stepsResponsesArr[i].length > 1) {
                var resp = stepsResponsesArr[i].split(',')
                resp = resp[resp.length - 1];
                if (resp == 1) {
                    ok = 1;
                }
                if (resp == 2) {
                    ok = 2;
                }
            } else {
                resp = stepsResponsesArr[i];
                if (stepsResponsesArr[i] == 1) {
                    ok = 1;
                }
                if (stepsResponsesArr[i] == 2) {
                    ok = 2;
                }
            }
            interArr[i] = resp;
        } else {
            ok = 3;
            interArr[i] = '';
        }
        var result = "";
        if (ok == 0) {
            respuestasOkArr[i] = 0;
            result = '<img src="../images/check_false.gif" style="vertical-align:middle"/>Incorrecta';
        };
        if (ok == 1) {
            respuestasOkArr[i] = 1;
            result = '<img src="../images/check_true.gif" style="vertical-align:middle"/>Correcta';
            nota = nota + 1;
        };
        if (ok == 2) {
            respuestasOkArr[i] = 1;
            result = '<img src="../images/check_true_m.gif" style="vertical-align:middle"/>Mejorable';
            nota = nota + 0.5;
        };
        if (ok == 3) {
            respuestasOkArr[i] = '';
            result = '<img src="../images/check_nulo.gif" style="vertical-align:middle"/>Sin Contestar';
        };
        var numResps = 0;
        if (typeof stepsResponsesArr[i] != 'undefined') {
            numResps = stepsResponsesArr[i].toString().split(',').length;
        }
        if (typeof stepsResponsesArr[i] != 'undefined') {
            txt += '<ul class="resultadosUl"><li>' + stepsTitlesArr[i] + '</li><li>' + numResps + '</li><li> ' + result + '</li></ul>';
        } else {
            txt += '<ul class="resultadosUl"><li>' + stepsTitlesArr[i] + ':</li><li>0</li><li>' + result + '</li></ul>';
        }
    }


    nota = (nota * 10) / totalSteps;
    nota = Math.round(nota);
	
    grabaejercicio(nota, interArr.toString(), respuestasOkArr.toString(), NotaCorte);

    var notaTxt = "";
    if (nota >= NotaCorte) {
        notaTxt += '<img style="vertical-align:middle;margin-right:5px" src="../images/correcionOk.jpg"/><span class="notaOk">Muy bien!!!.</span> Has superado el ejercicio. ';
        nota = '<span class="notaOk">' + nota + '</span>';
    };
    if (nota < NotaCorte) {
        notaTxt += '<img style="vertical-align:middle;margin-right:5px;" src="../images/correcionKo.jpg"/><span class="notaKo">No lo has hecho bien!!!.</span> Te recomendamos que repases los contenidos. ';
        nota = '<span class="notaKo">' + nota + '</span>';
    }

    notaTxt += "<br/>Has conseguido <b>" + nota + "</b> puntos sobre <b>" + scoreMax + '</b>.';

    $('input').remove();
    $('#resultsLi').append(txt);
    $('.resultTxt').append(notaTxt);
    $('#resultados').append('<div id="bot" style="text-align:center;"></div>');
    $('#resultados').slideDown('slow');
}


function loadNextStep() {
    activeStep++;
    simuladorTries = 0;
    var stepFile = simulationFilesArr[activeStep];
    loadSimContent(stepFile);
}


function repeatStep() {
    stopVideos();
    $('.pastilla:eq(2)').slideUp('slow');
    $('.pastilla:eq(1)').slideDown('slow');
}

function initStep() {
    $('.pastilla:eq(0)').slideUp('slow');
    $('.pastilla:eq(1)').slideDown('slow');
    stopVideos();
}

function showEnunciado() {
    $('.pastilla:eq(1)').slideUp('slow');
    $('.pastilla:eq(0)').slideDown('slow');
}

function finishSimulation() {
    $('.pastilla').hide();
    showResults();

}
var simHelpWindow;
function openSimHelp(file) {
    if (typeof simHelpWindow != 'undefined') {
        simHelpWindow.close();
    }
    simHelpWindow = window.open(file, '', 'status=yes,scrollbars=yes,top=0,left=0,resizable=yes,width=800, height=600"');
    simHelpWindow.focus();
    setTimeout(function() {
        $(simHelpWindow.document).find('.caja').css('visibility', 'visible');
    }, 1000)
}

function stopVideos() {
    $('video').each(function(index) {
        try {
            $('video')[index].pause();
        } catch (e) {
            addControl('#ERROR : ' + e);
        }
    })
}