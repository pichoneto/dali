//	JavaScript Document
//	Luis Miguel del Corral
//	Version:	1.0
//	Fecha:	21 Junio 2016
/*
	Datos:	Se eliminan consolas innecesarias a d�a de hoy

*/
var activePreg = 0;
var activeTema = 0;
var startedTemaTest = false;
var totTemasEvalIni = 0;

$(document).ready(function() {
    $('ul[id|="tema"], #divControlesTestInit').hide();
    $('#finTestIni').hide();
    $('#resultados').hide();
    $('#temasContent').hide();
    totTemasEvalIni = $('ul[id|="tema"]').length - 1;
    var numObjetives = doLMSGetValue('cmi.objectives._count');
    var resultTxt = "";
    var estadoObj = "";
    var notaObj = "";
    var done = false;
    for (i = 0; i < numObjetives; i++) {
        var estadoObj = doLMSGetValue('cmi.objectives.' + i + '.status');
        var notaObj = doLMSGetValue('cmi.objectives.' + i + '.score.raw');
        estadoObjTxt = convertScormString(estadoObj);
        if (estadoObj.charAt(0).toLowerCase() != 'n') {
            resultTxt += '<p class="centrado">' + estadoObjTxt + ' Nota : ' + notaObj + '</p>';
            done = true;
        }
    }

    if (done) {
        $('#intro p').remove();
        $('#intro h1 .h1').append("<br/>Estos son los resultados de tu propia valoraci&oacute;n de conocimiento:")
        if (notaObj <= 2.5) {
            val = $('.ko1').html();
        }
        if (notaObj >= 2.5 && notaObj < 5) {
            val = $('.ko2').html();
        }
        if (notaObj >= 5 && notaObj < 7.5) {
            val = $('.ok1').html();
        }
        if (notaObj >= 7.5) {
            val = $('.ok2').html();
        }
        $('#intro').append('<h2 class="centrado">' + val + '</h2');

    }
    $('.caja').css('visibility', 'visible');
    hidePreloader();
});

function activateTestIniButtons() {
    $('#prevTemaTest, #nextTemaTest, #finTestIni').unbind();
    $(document).off('click', '#prevTestIni').on('click', '#prevTestIni', function() {
        goToNextPreg(activePreg - 1);
    });
    $(document).off('click', '#nextTestIni').on('click', '#nextTestIni', function() {
        goToNextPreg(activePreg + 1);
    });
    $(document).off('click', '#nextTemaTest').on('click', '#nextTemaTest', function() {
        goToNextTema(activeTema + 1);
    });
    $(document).off('click', '#prevTemaTest').on('click', '#prevTemaTest', function() {
        goToNextTema(activeTema - 1);
    });
    $(document).off('click', '#finTestIni').on('click', '#finTestIni', function() {
        finishTestIni()
    });
}

function convertScormString(str) {
    var val;
    if (str == "not attempted") {
        val = 'No intentado';
    }
    if (str == "failed") {
        val = 'No superado';
    }
    if (str == "passed") {
        val = 'Superado';
    }
    return val
}

function startTema() {
    addControl('startTema()');
    $('ul[id|="tema"]').hide();
    $('#temasContent').show();
    activePreg = 0;
    goToNextPreg();
}

function goToNextTema(_temaNum) {
    startedTemaTest = false;
    activeTema = _temaNum;
    startTema();
}

function goToNextPreg(_preg) {
    activateTestIniButtons();
    var totTemaPregs = $('#tema-' + activeTema).find('>li').length;
    if (_preg && _preg <= totTemaPregs) {
        activePreg = _preg;
        $('#intro').animate({
            'margin-top': 0,
        }, 500, function() {
            $('#temasContent').css('height', $('#testInicial').height() - $('#intro').outerHeight(true) - $('#divControlesTestInit').outerHeight(true));
        });
        $('#tema-' + activeTema).show();
    } else {
        activePreg = 0;
    }

    $('#prevTestIni').unbind('click');
    if (activePreg <= 1 || activePreg > totTemaPregs) {
        $('#prevTestIni').css('opacity', 0.2);
        $('#prevTestIni').click(function() {
            return false;
        });
    } else {
        $('#prevTestIni').css('opacity', 1);
        $(document).off('click', '#prevTestIni').on('click', '#prevTestIni', function() {
            goToNextPreg(activePreg - 1);
        });
    }

    $('#divControlesTestInit').hide();
    if (activePreg >= 1) {
        $('#divControlesTestInit').show();
    };

    $('#prevTemaTest').css('opacity', 1);
    $('#prevTemaTest').show();
    if (activeTema <= 0) {
        $('#prevTemaTest').hide();
    }

    $('#nextTestIni').unbind('click');

    if (activePreg >= totTemaPregs) {
        $('#nextTestIni').css('opacity', 0.2);
        $(document).off('click', '#nextTestIni').on('click', '#nextTestIni', function() {
            return false;
        });
        if (activeTema < totTemasEvalIni) {
            $('#nextTemaTest').css('opacity', 1);
            $('#nextTemaTest').show();
        } else {
            $('#finTestIni').css('opacity', 1);
            $('#finTestIni').show();
        }
    } else {
        $('#nextTestIni').css('opacity', 1);
        $(document).off('click', '#nextTestIni').on('click', '#nextTestIni', function() {
            goToNextPreg(activePreg + 1);
        });
        $('#nextTemaTest').hide();
    }

    if (activePreg >= 0 && activePreg < totTemaPregs) {
        $('#tema-' + activeTema + ' > li').animate({
            opacity: 0.2
        });

        var obj = $('#tema-' + activeTema + ' > li:eq(' + activePreg + ')');

        if (!startedTemaTest) {
            $('#intro').empty();
            $('#intro').append(obj.html());
            obj.hide();
            animateTestIniDiv($('#intro'));
            startedTemaTest = true;
        }

        var container = $('#temasContent');
        var pos = obj.offset().top - container.offset().top + container.scrollTop();
        obj.animate({
            opacity: 1,
        });
        $('#temasContent').animate({
            scrollTop: pos,
        });
        initializeInitTest();
    }
}

function initializeInitTest() {
    $(document).off('click', 'ul.puntuaresp li').on('click', 'ul.puntuaresp li', function() {
        $(this).parent('ul').attr('on', ($(this).index() + 1));
        marcaOpcion($(this), 1);
        goToNextPreg(activePreg + 1);
    });

    $('ul.puntuaresp li').hover(
        function() {
            marcaOpcion($(this), true);
        },
        function() {
            marcaOpcion($(this));
        }
    );
    activateTestIniButtons();
}

function marcaOpcion(obj, opc) {

    var totalLi = obj.parent().find('li').length;
    for (i = 0; i <= totalLi; i++) {
        if (!obj.parent('ul').attr('on')) {
            selectPregOption(obj.parent().find('li:eq(' + (i) + ')'), 0.5);
        } else {
            if (i > obj.parent('ul').attr('on')) {
                selectPregOption(obj.parent().find('li:eq(' + i + ')'), 0.5);
            }
        }
    }
    if (opc) {
        for (i = 0; i <= obj.index(); i++) {
            selectPregOption(obj.parent().find('li:eq(' + i + ')'), 1);
        }
        if (opc == 1) {
            for (i = 0; i <= totalLi; i++) {
                obj.parent().find('li:eq(' + i + ')').attr('on', false);
            }
            obj.attr('on', true);
        }
    }
}

function selectPregOption(obj, opc) {
    obj.css({
        opacity: opc,
    })
}

var resultsArr;

function finishTestIni() {

    $('#testInicial').css('overflow-y', 'auto');
    $('ul[id|="tema"], #divControlesTestInit, #intro').hide();

    var testIniResponses = new Array();
    var responses = "";
    var notaTestIni = 0;
    resultsArr = new Array();

    for (i = 0; i <= totTemasEvalIni; i++) {

        //Pinto los enunciados de cada tema				
        var temaQuest = $('#tema-' + i + ' > li:eq(0)').clone();
        $('#resultsTestIni').append(temaQuest);

        //Recupero las respuestas
        var obj = $('#tema-' + i);
        var temaNumPregs = $('#tema-' + i + ' > li').length;
        var respuesta = "";
        var respVal = "";
        var onVal = "";
        $('#tema-' + i).find('li .puntuaresp').each(function(index, value) {
            var onVal0 = $(this).attr('on');
            if (onVal0 == "" || onVal0 == undefined) {
                onVal += 0;
            } else {
                onVal += onVal0;
            }
        });
        respuesta += onVal;

        testIniResponses.push(respuesta);
        // calculo los resultados de cada tema
        var numResp = testIniResponses[i].toString().split('').length;
        var sum = 0;
        for (z = 0; z < numResp; z++) {
            sum = sum + parseInt(testIniResponses[i][z]);
        }

        var n = 0;
        for (z = 0; z < temaNumPregs; z++) {
            n = n + $('#tema-' + i + ' > li:eq(' + (z) + ') > ul.puntuaresp > li').length;
        }

        var totElements = 100 / n;
        var percent = Math.round(sum * totElements);
        resultsArr.push(percent);
        if (percent >= 50) {
            estilo = "notaOk"
        } else {
            estilo = "notaKo"
        };
        $('#resultsTestIni li:eq(' + i + ')').append('<span class="percent  ' + estilo + '">' + percent + '%</span>');
        $('#resultsTestIni li').attr('style', '');
        $('#resultsTestIni li').show();
        $('#resultsTestIni input').remove();

    }

    var totPercent = 0;
    var resOk = new Array();

    for (j = 0; j < testIniResponses.length; j++) {
        totPercent += resultsArr[j];
        if (resultsArr[j] >= NotaCorte) {
            resOk.push(1);
        } else {
            resOk.push(0);
        }
    }
    notaTestIni = Math.round((totPercent * 100) / (testIniResponses.length * 100));
    $('#resultados .percent').html(notaTestIni + '%');

    if (notaTestIni <= 25) {
        pos = 0;
    }
    if (notaTestIni >= 25 && notaTestIni < 50) {
        pos = 1;
    }
    if (notaTestIni >= 50 && notaTestIni < 75) {
        pos = 2;
    }
    if (notaTestIni >= 75) {
        pos = 3;
    }

    notaTestIni = Math.round(notaTestIni / 10);

    grabaejercicio(notaTestIni, resultsArr.toString(), resOk.toString(), NotaCorte);

    $('#temasContent').hide();
    $('#resultados ul li').hide();
    $('#resultados ul li:eq(' + pos + ')').show();
    $('#resultados').show();
    $('#testInicial').show();
    $('#resultados').show();

}

function animateTestIniDiv(obj) {
    var padTop = (($('#testInicial').innerHeight() - obj.innerHeight())) / 2;
    obj.animate({
        'margin-top': padTop,
    }, 1000, function() {

    });
}