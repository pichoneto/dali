var respuestasNomina = [];
var respuestasreales=[]	
var intentos = 0;
var feedback = [];
var feeedbackOk,feedbacknotried;
var numIntentos;

var okNominas = new Array();
var answerNomina = new Array();

var justNomina;

function nominaEx(){	
	loadPlantillaNomina("../src/ejercicios/factura"+$(nominaXML[0]).attr('plantilla')+".html");	
	//creaDivControl();
}

function loadPlantillaNomina(_file){	
	var jqxhr = $.get( _file, function() {
			//alert( "success" );
		})
		.done(function(file) {	
			//$(file).appendTo('#ejercicio');	
			$('#ejercicio').html($(file))
			$('#corregir').append($('<input>').attr("type", "button").attr("id","botCorregir").click(function (){corregirNomina()}));  
			$('#botCorregir').attr("value","Corregir");
			$('#botCorregir').addClass('bot');
			$('#corregir').css('margin-top','50px')	
			
			prepararNomina(nominaXML[0]);	
			//$('<div></div>').attr( 'id','resultados').appendTo('#ejercicio');
		}).fail(function() {
			alert( "Error de carga html "  + _file);
		})
}



function prepararNomina(xml){
	var tipo, enunciado,cuestion,instrucciones;
	tipo = nominaXML.attr('tipo');
	nominaXML.find("ITEMS ITEM DATA ENUNCIADO:first").each(function () {
		enunciado =$(this).text();					
	});	
	instrucciones = nominaXML.attr('instrucciones');							
		
	nominaXML.find("ITEMS ITEM OPTION").each(function () { 
		cuestion = $(this)[0].childNodes;	
			$(this).children().each(function (){
				respuestasNomina.push($(this).text());
					if ($(this).text()!=""){
							respuestasreales.push($(this).text());
					}
			});					
	});
	
	$("#enunciadoEjer").html(enunciado);	
	$('#instruccionesEjer').append(instrucciones);	
	
	nominaXML.find("EMPRESA").each(function () {
		$("#empresa").text($(this).text());					
	});
	nominaXML.find("DOMICILIO").each(function () {
		$("#domicilio").text($(this).text());					
	})
	nominaXML.find("LOCALIDAD").each(function () {
		$("#localidad").text($(this).text());					
	})
	nominaXML.find("CP").each(function () {
		$("#cp").text($(this).text());					
	})
	nominaXML.find("PROVINCIA").each(function () {
		$("#provincia").text($(this).text());					
	});
	nominaXML.find("ENTIDAD").each(function () {
		$("#entidad").text($(this).text());					
	});
	nominaXML.find("CLAVE").each(function () {
		$("#clave").text($(this).text());					
	});
	nominaXML.find("SIGLAS").each(function () {
		$("#siglas").text($(this).text());					
	});
	
	nominaXML.find("CIF").each(function () {
		$("#cif").text($(this).text());					
	});
	nominaXML.find("CODIGO-SS").each(function () {
		$("#codigo-ss").text($(this).text());						
	});
	nominaXML.find("EMPLEADO").each(function () {
		$("#empleado").text($(this).text());										
	});
	nominaXML.find("EMPRESA").each(function () {
		$("#empresa").text($(this).text());										
	});
	nominaXML.find("NIF").each(function () {
		$("#nif").text($(this).text());											
	});
	nominaXML.find("LIBRO").each(function () {
		$("#libro").text($(this).text());										
	});
	nominaXML.find("AFILIA-SS").each(function () {
		$("#afilia-ss").text($(this).text());										
	});
	nominaXML.find("CATEGORIA").each(function () {
		$("#categoria").text($(this).text());									
	});
	nominaXML.find("GRUPO").each(function () {
		$("#grupo").text($(this).text());											
	});
	nominaXML.find("ANTIGUEDAD").each(function () {
		$("#antiguedad").text($(this).text());										
	});
	nominaXML.find("FECHA-LIQUIDA").each(function () {
		$("#fecha-liquida").text($(this).text());										
	});
	nominaXML.find("FECHA-NOMINA").each(function () {
		$("#fecha-nomina").text($(this).text());										
	});
	nominaXML.find("FEEDBACKOK").each(function () {
			feeedbackOk = $(this).text();					
	});
	nominaXML.find("NOTRIED").each(function () {
			feedbacknotried = $(this).text();					
	});
	var FEEDBACKBUCLE = "FEEDBACK";
	for (var i=0;i<=numIntentos;i++) {
		var	FEEDBACKIteracion= FEEDBACKBUCLE+ i;
		nominaXML.find(FEEDBACKIteracion).each(function () {
			feedback.push($(this).text());					
		});				
	}
	nominaXML.find("ITEMS ITEM JUSTIFICACION").each(function () {
			justificacion = $(this).text();	
			justNomina = justificacion;
	});

	nominaXML.find("COMPLEMENTO1").each(function () {
		$("#complemento1").text($(this).text());					
	});
	nominaXML.find("COMPLEMENTO2").each(function () {
		$("#complemento2").text($(this).text());					
	});
	nominaXML.find("COMPLEMENTO3").each(function () {
		$("#complemento3").text($(this).text());					
	});	
	nominaXML.find("TRANSPORTE1").each(function () {
		$("#otras1").text($(this).text());					
	});
	nominaXML.find("TRANSPORTE2").each(function () {
		$("#otras2").text($(this).text());					
	});
	nominaXML.find("TRANSPORTE3").each(function () {
		$("#otras3").text($(this).text());					
	});
	
	$(".item").focusout(function(){
		$(this).val(formatearCampo($(this),$(this).val()));
	})
	$(".item").focus(function(){		
		$(this).val(desformatearCampo($(this),$(this).val()));
	})
	
	$(".item").each(function(index){		
		if (respuestasNomina[index]==""){					
			$(this).attr("disabled","true");			
		}	
	})
	onExEndLoaded();
}





function fillNomina(){
	$(".item").each(function( index, value ) {	
		if ($(this).attr("disabled")!="disabled"){
			$(this).val(formatearCampo($(this),respuestasNomina[index]))
		}
	});
}

function devolverNotaNomina(nota_entero){
	var salida;	
	var nota = nota_entero.toString();
	if (nota.indexOf(".")==-1){
			salida = nota;
	}
	else{
		salida = nota.split(".")[0];
		salida = salida + ".";		
		if (nota.split(".").length>1){			
			salida = salida + nota.split(".")[1].substring(0,2);
		}
	}	
	return salida;
}



function corregirNomina(){
	var aciertos=0;	
	okNominas = new Array();
	answerNomina = new Array();
	$(".item").each(function( index, value ) {		
		if ($(this).attr("disabled")!="disabled"){			
			answerNomina.push(this.value.replace(",","."));			
			//alert(this.value + '   ' + respuestasNomina[index]);
			if (convertirNumero(this.value)==convertirNumero(respuestasNomina[index])){			
				aciertos = aciertos +1;	
				okNominas.push(1);
			}else{
				okNominas.push(0);	
			}
		}	
	});
	//alert(scoreMax + ' - ' + aciertos + ' : ' + respuestasreales.length)	
	var nota = scoreMax*aciertos/respuestasreales.length ;	
	intentos = intentos+1;
	addControl("INTENTOS:" + intentos);
	addControl("NOTA: " + nota);
	addControl("ACIERTOS: " + aciertos + ' de ' +respuestasreales.length );
	
	if (intentos  >= numIntentos){
		mostrarResultadosNomina();
		showResults(aciertos,okNominas.length,intentos,nota);
		$('#corregir').remove();
		showJustificacion(justNomina);
		saveNomina(devolverNotaNomina(nota));
	}
	
	if (aciertos < (respuestasreales.length/2)){
			showFeedback('<b>' + feedback[intentos-1]+'</b>');	
	}else{
		mostrarResultadosNomina();		
		showResults(aciertos,okNominas.length,intentos,nota);
		showFeedback('<b>' + feeedbackOk+'</b>');
		$('#corregir').remove();
		showJustificacion(justNomina);
		saveNomina(devolverNotaNomina(nota));	
	}
	
	
}

function mostrarResultadosNomina(){	
	$(".item").each(function( index, value ) {	
		if ($(this).attr("disabled")!="disabled"){		
			if (formatearCampo($(this),$(this).val())==formatearCampo($(this),respuestasNomina[index])){			
				$(this).addClass("correcto");
			}else{	
				if ($(this).hasClass("entero")){
					$(this).val(respuestasNomina[index]);
				}else{
					$(this).val(formatearCampo($(this),respuestasNomina[index]));
				}				
				$(this).addClass("incorrecto");
			}		
		}
	});
}

function saveNomina(nota){
	exercisesNotes[actvPage] = nota;
	exercisesInter[actvPage]= answerNomina;
	exercisesOk[actvPage]= okNominas;
	sendNota();		
}

function formatearCampo(elemento,valor){
	salida =valor;
	if(valor!=undefined){
		if (!$(elemento).hasClass("entero") && !$(elemento).hasClass("alfa") && !$(elemento).hasClass("dni") && !$(elemento).hasClass("fecha") && !$(elemento).hasClass("barra")){
				salida = convertirNumero(valor);
			}
			if ($(elemento).hasClass("alfa")){
					salida =valor.toUpperCase();
			}
			if ($(elemento).hasClass("alfaOrig")){
					salida =valor;
			}
			
			if ($(elemento).hasClass("barra")){
					if ((valor.indexOf("/")==-1)&&(valor.length==12)){					
						salida = valor.substring(0, 2) + "/" + valor.substring(2,valor.length);
					}
			}
			if ($(elemento).hasClass("dni")){	
				if((valor.indexOf("-")==-1)){
					if ((valor.length>8)){					
						salida = valor.substring(0, valor.length-1) + "-" + valor.substring(valor.length-1,valor.length);
					}
					
					var val = valor.split("");
					
					if ((valor.split("").length<8)){					
						salida = valor.substring(0, valor.length-1) + "-" + valor.substring(valor.length-1,valor.length);
					}
					
				}
				salida = salida.toUpperCase();
					
			}
			if ($(elemento).hasClass("fecha")){				
					if ((valor.length==5)){					
						salida = "0" + valor;
					}
			}
			return salida;
	}
}



function desformatearCampo(elemento,valor){
	salida = valor;
	if (!$(elemento).hasClass("entero") && !$(elemento).hasClass("alfa") && !$(elemento).hasClass("dni") && !$(elemento).hasClass("fecha")){
			salida = valor.replace(/\./g,'');
	}
	if ($(elemento).hasClass("dni")){
			salida = valor.replace(/-/g,'');
	}
	return salida;
}


function convertirNumero(numero){
	var salida;
	if ((numero=="") || (numero==null)){
		salida =""
	}else{
		var valor = numero;
		var decimales;
		var numdecimales ;
		var miles;
		decimales=",";
		miles=".";
		numdecimales = parseInt(valor.substring(valor.indexOf(".")+1,valor.length).length);
		if ((numdecimales<=2)&&(numdecimales>0)){decimales=".";miles=","}
		if (decimales==undefined){
			numdecimales = parseInt(valor.substring(valor.indexOf(",")+1,valor.length).length);
			if ((numdecimales<=2)&&(numdecimales>0)){decimales=",";miles="."}
		}	
		if (miles=="."){valor = valor.replace(/\./g,'')}else{valor = valor.replace(/\,/g,'')}
		valor = valor.replace(/\./g,',')
		partenetera = valor.split(',')[0];
		partedecimal = valor.split(',')[1];
	
		salida = "";
		for(i = partenetera.length-1; i>-1; i--){ 
			salida = partenetera.substring(i,i+1)+ salida ;		
			if ((i-(partenetera.length))%3==0&&(i!=0)&&(i!=partenetera.length-1)){
			salida = "." + salida;
			}
		}    
		if ((partedecimal!="")&&(partedecimal!=null)){
			if (partedecimal.length<2) {partedecimal=partedecimal +"0"}
			salida = salida + "," + partedecimal
			
		}else{
			salida = salida + ",00" 
		}
	   
	}
	return salida
}
