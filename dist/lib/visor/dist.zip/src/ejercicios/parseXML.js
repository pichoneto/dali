// JavaScript Document
/////////////////////////////////////////////////////////////////////////////////////////////
// Adams Carga xml ejercicios interactivos
// gonzalomonjardin@adams.es
// 17-12-2013
/////////////////////////////////////////////////////////////////////////////////////////////

var exercisesList = new Array();
var exercisesType = new Array();
var exercisesNotes = new Array();
var exercisesInter = new Array();
var exercisesOk = new Array();
var totalOkArr = new Array();
var actvPage = 0;
var totalPages = 0;
var relAllXML; 
var relOneXML; 
var fraseXML;
var checkOptionXML;
var bloquesXML;
var sopaLetrasXML;
var nominaXML;
var tipo;

var myOpener = parent;
var parentIframeEx = myOpener.iframeEx;
var parentObjetive = myOpener.objetivo;


$(document).ready(function(){ 
	$('body').show();
});

function loadXML(_file,_new){
	showPreloader('Cargando contenido ejercicio ...');
	if(_new){
		exercisesList = new Array();
		exercisesType = new Array();
		exercisesNotes = new Array();
		exercisesInter = new Array();
		exercisesOk = new Array();
		relAllXML = ""; 
		relOneXML = ""; 
		fraseXML = "";
		checkOptionXML = "";
		bloquesXML = "";
		sopaLetrasXML = "";
		nominaXML = "";
		actvPage = 0;
		$('#paginacion').empty();
	}
	 
	if(myXmlFile==""){
			totalPages = 1;			
			manageExercises();			
		}else{	
			var loadFile = $.get(_file, function() {
					//alert( "success" );
				})
				.done(function(xml) {							   
					$(xml).find("ITEMS").each(function () {
						saveData = $(this).attr('recordScore');
						NotaCorte = $(this).attr('notaCorteGlobal');
						objetivo = $(this).attr('obj');
						scoreMax = $(this).attr('scoreBase');
						numIntentos = parseInt($(this).attr('tries'))+1;
						
					});
					addControl('saveData:'+saveData);
					addControl('NotaCorte:'+NotaCorte)
					addControl('objetivo:'+objetivo)
					addControl('scoreMax:'+scoreMax)
					addControl('numIntentos:'+numIntentos)					
					$(xml).find("ITEMS > ITEM").each(function () {				
						var tipo = $(this).attr('tipo');
						exercisesList.push($(this));
						exercisesType.push(tipo);
					});			
					
					$(xml).find("ITEMS PALABRAS").each(function () {				
						sopaLetrasXML = $(this);
					});
					
					if(sopaLetrasXML){
						exercisesList.push($(xml));
						exercisesType.push('sopaLetras');
					}
					totalPages = exercisesType.length;	
					addControl('exercisesType:'+exercisesType)
					addControl('exercisesList:'+exercisesList)
					manageExercises();					
				})
				.fail(function() {
					alert( "Error de carga XML  "  + _file);
				})
				.always(function() {

			});
		}
}


function manageExercises(_num){
	addControl("manageExercises: " + _num);	
	showPreloader('Creando ejercicio...');
	if(_num!=undefined){	
		actvPage = _num;		
	}
	tipo = exercisesType[actvPage];		
	
	if(typeof num == 'undefined' && ejerType!='seleccionaTexto'){		
		resetCommonElements();
	}	
	if(ejerType=='seleccionaTexto'){
		saveData = true;
	}
	
	if(tipo=='relacionaAll'){
		relAllXML = exercisesList[actvPage];
		relacionaAllEx();
	}					
	if(tipo=='relacionaOne'){
		relAllXML = exercisesList[actvPage];
		relacionaAllEx(true);
	}			
	if(tipo=='frase'){
		fraseXML = exercisesList[actvPage];
		fraseEx();	
		hidePreloader();		
	}
	if(tipo=='fraseDesplegables'){
		fraseXML = exercisesList[actvPage];
		fraseDesplegableEx();	
		hidePreloader();		
	}
	if(tipo=='nomina'){
		nominaXML = exercisesList[actvPage];
		nominaEx();	
		hidePreloader();
	}					
	if(tipo=='checkOption'){
		checkOptionXML = exercisesList[actvPage];
		checkOptionEx();
	}
	if(tipo=='bloques'){
		bloquesXML = exercisesList[actvPage];
		bloquesEx();
	}				
	if(tipo=='sopaLetras'){
		sopaLetrasXML = exercisesList[actvPage];	
		sopaLetrasEx();
	}
	
	setPage();	
	debug = true;
	if(debug){
		showEjerControls();
	}
}

function setPage(){	
	addControl('setPage : ' + actvPage)
	var pagsTxt ="";
	if(totalPages>1){
		if(actvPage>0){
			pagsTxt = '<a class="prevPag" onclick="manageExercises('+(actvPage-1)+')"><img src="../src/ejercicios/imgs/prevBtn.jpg" width="30px" height="30px" style="vertical-align:middle;margin-right:5px;"/></a>';
		}
		pagsTxt += (actvPage+1) + ' de ' + totalPages;		
		if(actvPage<totalPages-1){
		pagsTxt += '<a class="postPag" onclick="manageExercises('+(actvPage+1)+')"><img src="../src/ejercicios/imgs/nextBtn.jpg" width="30px" height="30px" style="vertical-align:middle;margin-left:5px;"/></a>';
		}
		$('#paginacion').html(pagsTxt);
	}
	//showSolutionArr();
}


function sendNota(){	
	addControl("sendNota: " + actvPage +'de'+ (totalPages-1));	
	if(parentIframeEx){// ejercicios en un nuevo iframe				
		addControl('Lamada a parent' + parentObjetive)
				for(i=0;i<exercisesNotes.length;i++){
					if(exercisesNotes[i] >= NotaCorte){
						totalOkArr.push(1);
					}else{
						totalOkArr.push(0);
					}
				}
				//addControl('totalOkArr : ' + totalOkArr);
				//addControl('exercisesInter : ' + exercisesInter);			
				myOpener.addArrayItem(totalOkArr,exercisesInter,$('H2').text());
				
	}else{ // ejercicios normales /////////////////////////////////////////////////////////////////////////////////////////////////////////////		
		if(actvPage == (totalPages-1)){					
					if(exercisesType.length > 1){ // Si existe m�s de un ejercicio						
						for(i=0;i<exercisesNotes.length;i++){
							if(exercisesNotes[i] >= NotaCorte){
								totalOkArr.push(1);
							}else{
								totalOkArr.push(0);
								}
						}
						var totalOk = 0;
						for(i=0;i<totalOkArr.length;i++){
							if(totalOkArr[i]==1){
								totalOk++;
							}
						}						
						var notaFinal = (totalOk*scoreMax)/exercisesType.length;
						grabaejercicio(notaFinal, exercisesInter.toString(),totalOkArr.toString(),NotaCorte);						
					}else{ // si es solo un ejercicio			
						var okresults;
						if(exercisesInter.length == 1 && exercisesType != 'bloques' && exercisesType != 'sopaLetras' && exercisesType != 'nomina'){
							if(parseInt(exercisesNotes[0]) >= NotaCorte){
								exOk = 1;
							}else{
								exOk = 0;
							}
							okresults = exOk;										
						}else{							
							for(i=0;i<exercisesOk.toString().split(",").length;i++){
								if(exercisesOk.toString().split(",")[i]== 1){
									totalOkArr.push(1);
								}else{
									totalOkArr.push(0);
								}
							}
							okresults = totalOkArr.toString();
						}						
						grabaejercicio(exercisesNotes.toString(), exercisesInter.toString(),okresults.toString(),NotaCorte);
						//repeatExButton($(".contenido"));
					}
				}
	}
}



function resetCommonElements(){
	if(tipo!='sopaLetras'){
		$('#enunciadoEjer').empty();
		$('#instruccionesEjer').empty();
	}
	$("#ejercicio").empty();
	$('#resultados').empty();
	$('#corregir').empty();
	$('#resultados').empty();
	$('#resultados').hide();
	return true;
}


//var botClose = '<a id="closeResultados" style="float:right;position:absolute;top:0;right:0;margin-right:5px;"><img src="../src/ejercicios/imgs/botClose.png"/></a>';
var botClose = '<div id="popBar" class="popBar degraded"><span class="popTitle" style="padding:0.3%;padding-left:1%;">Resultados</span><a title="cerrar" id="closeResultados"><img src="../images/recursos/botClose.png" style="float:right;vertical-align:middle;cursor:pointer;" alt="cerrar"/></a></div> ';

function showResults(aciertos,numopciones,intentos,nota,fallos){
	if(nota % 1 != 0){
		nota = nota.toFixed(1);
	}	
	if( parseInt(nota) >=NotaCorte){
		var img = 'imgs/correcionOk.jpg';
	}else{
		var img = 'imgs/correcionKo.jpg';	
	}	
	var fallosTxt ='';
	if(fallos){
		fallosTxt = " y fallado <b>" + fallos + '</b>';	
	}
	var txt = '<img src="../src/ejercicios/'+img+'" style="vertical-align:middle;margin-right:5px;"/>';
	//showFeedback(txt)
	txt += 'Has acertado <b>' + aciertos + '</b> '+fallosTxt+' de  un total de <b>' + numopciones + '</b> en un total de<b> ' + intentos +' </b>intentos.<br/>';
	txt += 'La nota m&iacute;nima para aprobar es <b>' + NotaCorte + '</b> y has obtenido <b>' + nota + '</b> sobre <b>' + scoreMax + '</b> puntos.';	
	showFeedback(txt);
	$('#resultados').append('<div id="bot" style="text-align:center;"></div>');
	//repeatExButton($("#corregir"));
}


function showFeedback(_txt){
	var exists = false;	
	if($('#velo').length <= 0){
		$('body').append('<div id="velo"></div>');
		$('#velo').css('opacity',0.5);
	}
	if($("#closeResultados").length<=0){
		$('#resultados').append(botClose);
		$('#botCorregir').hide();
		//$('#resultados').append('<div id="txtResultado"></div>');
		$("#closeResultados").live("click", function(){			
			 hideObj($('#resultados'));
			 setTimeout(function() {$('#resultados').empty();}, 500);
			 hideObj($('#velo'),true);
			 $('#botCorregir').show();
		});
		exists = true;
	}	
	if($("#popContent").length>0){
		_txt = "<br>"+_txt;	
		$('#popContent').append(_txt);		
	}else{
		$('#resultados').append('<div id="popContent" class="popTxt" style="margin-top:5px">' + _txt + '</div>');
	}	
	centerEjerDiv($('#resultados'));
	return true;
}


function showJustificacion(txt){
	if(txt!=""){
		$('#ejercicio').after('<div id="justificacion" class="resaltado" style="padding:10px;margin:10px 10%;float:left;width:80%"><p>' + txt + '</p></div>');
	}
}

function showSolutionArr(){
	addControl('exercisesNotes: ' + exercisesNotes);
	addControl('exercisesInter: ' + exercisesInter);
	addControl('exercisesOk: ' + exercisesOk);	
}


function centerEjerDiv(_div){
	_div.css('position','absolute');	
	var totalW = $(window).width();
	var totalH = $(window).height();
	var divW = _div.outerWidth(true);
	var divH = _div.outerHeight(true);	
	//totalW = $('#ejercicio').width();
	totalH = $('#ejercicio').height();	
	var posX = (totalW - divW)/2;
	var posY = ((totalH - divH)/2)+$('#ejercicio').position().top;	
	_div.css('z-index',250);
	_div.css('left',posX);
	_div.css('top',posY);
	showObj(_div);
}


var botEjers ='';
function showEjerControls(){
	if($('#ejerControls').length<=0){
		botEjers += '<a id="ejerControls"onclick="fillCheckSolution()">checkBox</a>';
		botEjers += ' / <a onclick="fillRelAllSolution()">rel All</a>';
		botEjers += '/ <a onclick="fillRelOneSolution()">rel All</a>';
		botEjers += '/ <a onclick="fillFraseSolution()">Frase</a>';
		botEjers += '/ <a onclick="fillBloquesSolution()">Bloques</a>'; 
		botEjers += '/ <a onclick="fillSopaSolution()">Sopa</a>'; 
		botEjers += '/ <a onclick="fillNomina()">Nomina</a>'; 
	}
	$('.debugMenu').append(botEjers)
	//$('#instruccionesEjer').append(botEjers)
}

