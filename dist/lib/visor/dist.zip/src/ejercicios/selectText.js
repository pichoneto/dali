// JavaScript Document
/////////////////////////////////////////////////////////////////////////////////////////////
// Adams ejercicio de seleccionar texto
// gonzalomonjardin@adams.es
// 28/01/2015
/////////////////////////////////////////////////////////////////////////////////////////////
var triesUsed = 0;
var selTextOkVals = new Array();
var selTextAnsw = new Array();

if(!window.Kolich){
  Kolich = {};
}

Kolich.Selector = {};
Kolich.Selector.getSelected = function(){
  var t = '';
  if(window.getSelection){
    t = window.getSelection();
  }else if(document.getSelection){
    t = document.getSelection();
  }else if(document.selection){
    t = document.selection.createRange().text;
  }
  return t;
}

Kolich.Selector.mouseup = function(){
  var st = Kolich.Selector.getSelected();
  if(st!=''){
	addTextSelection(st.toString());
  }
}


function unselectText(){
	if(window.getSelection){   	
			window.getSelection().removeAllRanges();
	  }else if(document.getSelection){   
	  
			document.getSelection().removeAllRanges();
	  }else if(document.selection){   
	  
			var selection = document.selection;      //get a selection object
            selection.empty();                //remove all ranges
	}
}

$(document).ready(function(){
  $(document).bind("mouseup", Kolich.Selector.mouseup);
  $('#ejercicio').append('<div>Estas son tus selecciones:</div>');
  $('#ejercicio').append('<ul id="selectedText"></ul>');
  $('#corregir').append($('<input name="corrige" id="botCorregir" value="Corregir" class="bot" type="button"/>').click(function (){corregirSelectedText()}));  
  $('#corregir').css('margin-top','50px');
 
});


function addTextSelection(txt){
	$('#selectedText').append('<li>'+txt+'<a onclick="$(this).parent().remove()"><img style="vertical-align:middle;margin-left:1%;" src="../images/recursos/delete.png"/></a></li>');
	 var text = $('#textos').html();
	$('#textos').html(text.replace(txt, '<span class="selectedText">'+txt+'</span>')); 
	unselectText();

}


function corregirSelectedText(){
	var ok = 0;
	var ko = 0;
	var numTextOptions = 0;
	var selectedText;
	selTextOkVals = new Array();
	selTextAnsw = new Array();
	
	for (i=1; i<=10;i++){
		if(isDefined("ok"+i)==true){
			numTextOptions++;
		}
	}
	
	if($('#selectedText').find('li').length<=0){
			 showFeedback("<b>Todav&iacute;a no has intentado el ejercicio.</b>");	
			 return false;
		
	}
	
	triesUsed ++;
	if(triesUsed>numIntentos || nota>=NotaCorte){		
		showSelectPhraseSolution();
	}
	
	$('#selectedText').find('li').each(function(){
		var itemText = $(this).text();
		selTextAnsw.push(itemText);
		var isOk = false;
		var okText;
		for (i=1; i<=10;i++){
			if(isDefined("ok"+i)==true){
				var texto = eval("ok"+i);
				if(simplifyString(texto) == simplifyString(itemText) ){
					isOk = true;					
				}
			}
		}	
		
		var str;
		if(isOk){
			ok++;
			selTextOkVals.push(1);
			var resultImg = '<img src="../images/check_true.gif" style="vertical-align:middle"/>';			
			str = '<span class="notaOk">'+itemText+'</span>'; 
		}else{
			selTextOkVals.push(0);
			ko++;
			var resultImg ='<img src="../images/check_false.gif" style="vertical-align:middle"/>';
			str = '<span class="notaKo">'+itemText+'</span>'; 
		}
		
		if(triesUsed>numIntentos){	
			 var text = $('#textos').html();
			 $('#textos').html(text.replace(itemText, str)); 
			 $(this).find('img').remove();
			$(this).prepend(resultImg);
			$('#botCorregir').remove();
		}
		
	});
	
	var nota = ((ok*10) / numTextOptions);	
	nota = Math.round(nota * 100) / 100;
	addControl('ok : ' + ok + '\ko:' + ko);	
	
	if(triesUsed>numIntentos || nota>=NotaCorte){		
		showResults(ok,numTextOptions,triesUsed,nota,ko);
		exercisesNotes[actvPage] = nota;
		exercisesInter[actvPage]= selTextAnsw;
		exercisesOk[actvPage]= selTextOkVals;
		sendNota();	
		
	}else{
		 showFeedback("<b>No lo has hecho bien.</b><br>Te quedan "+((numIntentos+1) - triesUsed)+" intentos.");
		 
		}
		
		
		
		
}

function showSelectPhraseSolution(){
	addControl('showSelectPhraseSolution(');
	for (i=1; i<=10;i++){
			if(isDefined("ok"+i)==true){
				var str = eval("ok"+i);
				var text = $('#textos').html();
			 	$('#textos').html(text.replace(str, '<span class="notaEmpty">'+str+'</span>')); 
			}
	}
		
	
}

function simplifyString(itemText){
	itemText = itemText.replace(/ /g,'');
	itemText = itemText.replace(/,/g,'');
	itemText = itemText.replace(/;/g,'');
	itemText = itemText.replace(/\./g,'');
	itemText = itemText.replace(/:/g,'');
	return itemText;
	
}