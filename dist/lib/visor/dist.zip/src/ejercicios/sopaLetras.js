/*Sopa de Letras*/

var casillas_x=20;
var casillas_y=20;
var caracterespermitidos = 'ABCDEFGHIJKLMNÑOPQRSTUVWXYZ';	
var palabrasSopa=[]
var respuestasSopa =[];
var tablero;
var intentos = 0;
var sopaInteractionsOk = new Array();		
var sopaOkArr = new Array();
var wordsOk = 0;
var showWords = 0;		

function Shuffle(o) {
	for(var j, x, i = o.length; i; j = parseInt(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
	return o;
};
	

function sopaLetrasEx(){
	
		casillas_x = parseInt(sopaLetrasXML.find("ITEMS").attr('numItemsFila'));
		casillas_y = parseInt(sopaLetrasXML.find("ITEMS").attr('numItemsFila'));	
    	showWords = sopaLetrasXML.find("ITEMS").attr('showWords');
		if(isNaN(casillas_x)){
			casillas_x = 20;
			casillas_y = 20;
		}
		tablero = new Array(casillas_x);
		palabrasSopa=[];
		for (i=0;i <casillas_x;i++ ){ 
			tablero[i] = new Array(casillas_y); 
		}
		
		var enunciado = sopaLetrasXML.find("ITEMS > ENUNCIADO").text();
		var instrucciones = sopaLetrasXML.find("ITEMS > INSTRUCCIONES").text();
		$('#enunciadoEjer').html(enunciado);
		$('#instruccionesEjer').html(instrucciones)
		
		sopaLetrasXML.find("ITEMS > PALABRAS > ITEM").each(function () {
			palabrasSopa.push($(this).text());						
		});		
	
		$('<div></div>').attr( 'id','sopaletras').appendTo('#ejercicio');
		$('<div></div>').attr( 'id','lateral').appendTo('#ejercicio');	
		$('<div style="float:right">x</div>').attr("id","cerrarxver").appendTo('#notasup').click(function (){VerSolucion()});	
		$('<div style="float:right">x</div>').attr("id","cerrarxocultar").appendTo('#notasup').click(function (){OcultarResultadosSopa()});	
		
		$('<div></div>').attr( 'id','palabrassopaletras').appendTo('#lateral')		
		$('#corregir').append($('<input>').attr("type", "button").attr("id","botCorregir").click(function (){MostrarResultadosSopa()}));  
		$('#botCorregir').attr("value","Corregir");
		$('#botCorregir').addClass("bot");
		prepararSopa();
		
		
		
		
		
	}

function setSopaPos(){
	
	var marginLeft =(( $('#ejercicio').innerWidth() - ($('#sopaletras').outerWidth(true) + $('.palabraSopa').outerWidth(true)))/2);
	
	marginLeft = (marginLeft*100)/$('#ejercicio').innerWidth();
	
	
	$('#sopaletras').css("margin-left", marginLeft+'%');
	$('#sopaletras').css("margin-bottom",'20px');	
}	

function prepararSopa(){	
	var salida="";		
	palabrasSopa = Shuffle(palabrasSopa);
	while(!llenartablero());
	pintartablero();
	$('#palabrassopaletras').hide();	
	for (i=0;i <palabrasSopa.length;i++ ){
		$('<div>'+palabrasSopa[i].toUpperCase()+'</div>').addClass('palabraSopa').appendTo('#palabrassopaletras')
	}
	if(showWords==1){
    $('#palabrassopaletras').show();
	}
	
	onExEndLoaded();
	
	
};

function quitardeLista(lista,valor){
 var auxiliar = [];
 $.each(lista, function( index, value ) {
	if (value !=valor){auxiliar.push(value);}
 });
 return auxiliar;
}	

function CorregirSopa(){
	var respuestasAcertadas =[];
	$.each(palabrasSopa, function( index, value ) {
		respuestasAcertadas.push(value);		
	});
	$(".fila").removeClass("faltaba");
	$(".fila").removeClass("acierto");
	
	$.each(respuestasSopa, function( index, value ) {
		var auxiliar = value.split('#');
		respuestax = auxiliar[0];
		respuestay = auxiliar[1];
		palabraactual = auxiliar[2];
		
		if (!$("#casilla"+respuestax+"_"+respuestay).hasClass("seleccionado")){
			respuestasAcertadas = quitardeLista(respuestasAcertadas,palabraactual);			
			$("#casilla"+respuestax+"_"+respuestay).addClass("faltaba");			
		}else{
			$("#casilla"+respuestax+"_"+respuestay).addClass("acierto");
		}
		
	});
	$(".seleccionado").each(function(){
		if (!$(this).hasClass("acierto")){
			!$(this).addClass("error")
		}
	});
	
	$(".palabraSopa").removeClass("encontrado");

	sopaOkArr = new Array();
	sopaInteractionsOk =  new Array();
	wordsOk = 0;

	$(".palabraSopa").each( function( index, value ) {						
			sopaOkArr.push(0)
	})

	for (var i=0;i<$(respuestasAcertadas).length;i++) {
		var valorOK = respuestasAcertadas[i].toUpperCase();
		
		
		$(".palabraSopa").each( function( index, value ) {						
			if ($(this).text()==valorOK){
				$(this).addClass("encontrado");				
				sopaOkArr[index] = 1;
				wordsOk ++;
			}
			sopaInteractionsOk[index]=$(this).text();
		})
		addControl(i + " respuestasAcertadas " + respuestasAcertadas[i])
		
	}	
	return true;
	//alert(sopaInteractionsOk.length)
}



function VerSolucion(){	
	$("#resultadosbarras").css("display","none");
	$(".acierto").each(function(){$(this).addClass("acierto_color");})
	$(".error").each(function(){$(this).addClass("error_color");})
	$(".faltaba").each(function(){$(this).addClass("faltaba_color");})
	//CorregirSopa();
	
	
}

function fillSopaSolution(){
	$(".posicionada").each(function(){$(this).addClass("seleccionado");})
	
}
function MostrarResultadosSopa(){
	CorregirSopa();	
	
	var errores =$(".error").length;
	var aciertos =$(".acierto").length;
	var faltaba=$(".faltaba").length;
	var total = aciertos+faltaba;
	var palabrasacertadas =$(".encontrado").length;
	var totalpalabras = $(".palabraSopa").length
	var fallos = $(palabrasSopa).length - palabrasacertadas;
	var puntosporletra  = scoreMax/total;
	//var puntuacion =  parseInt((aciertos*puntosporletra) - (errores*puntosporletra));
	var puntuacion = parseInt(( palabrasacertadas*10)/$(palabrasSopa).length);
	var showSopaSolution = false;
	//alert(aciertos + "  " + errores + " : " + total)
	if(aciertos != '0' || errores !='0'){
			if (puntuacion <0) {puntuacion =0}
			intentos ++;
			
			
			var notaText = "Tu nota es de " + puntuacion + " puntos sobre " + scoreMax;
			
			if(wordsOk == undefined){
				wordsOk = 0;
			}
			var sopaOkResp = wordsOk-palabrasSopa.length;
			if(sopaOkResp<0){
				sopaOkResp = sopaOkResp*(-1);	
			}
			
			if (puntuacion>=parseInt(NotaCorte)){
				//sopaOk = 1;
			}
			
			
			//alert(wordsOk)
			if (intentos >= parseInt(numIntentos)){
				if (puntuacion>=parseInt(NotaCorte)){
					_text = "Muy bien.Has superado el ejercicio.\n"+ notaText ;
				}else{
					_text = "Has agotado el número de intentos.\n" + notaText ;
				}	
				
				showSopaSolution = true;
				showResults(wordsOk,palabrasSopa.length,intentos,puntuacion);		
				
			}else{				
				if (aciertos!=total){
					_text = "Tienes "+ (numIntentos-intentos).toString()+" intento/s más";
				}else{
					_text = "Muy bien.Has superado el ejercicio. "+ notaText ;
					showResults(wordsOk,palabrasSopa.length,intentos,puntuacion);
					showSopaSolution = true;	
				}
			}
			
			if (intentos < parseInt(numIntentos)){
				showFeedback('<b>'+_text +"</b>");	
			}

			if(showSopaSolution == true){				
				VerSolucion();	
				$("#corregir").css("display","none");
				exercisesNotes[0] = puntuacion;
				exercisesInter[0]= sopaInteractionsOk;
				exercisesOk[0]= sopaOkArr;
				//alert(sopaOkArr)
				sendNota();
			}
	}else{
		showFeedback('<b>Todav&iacute;a no has intentado el ejercicio.</b>');
		}
	
}


function comprobarLibre(posicionx,posiciony,longitud,horizontal){
			var salida = 1;
			if (horizontal){						
						for (j=0;j <longitud;j++ ){
							if (tablero[posicionx][posiciony+j]!=undefined){
								salida=0;							
							}
							if (posicionx>0){
								if (tablero[posicionx-1][posiciony+j]!=undefined){
									salida=0;																
								}				
							}	
							if (posicionx<(casillas_x-1)){
								if (tablero[posicionx+1][posiciony+j]!=undefined){
									salida=0;																
								}				
							}	
						
							
						}						
					}
					else{
						for (j=0;j <longitud;j++ ){
							if (tablero[posicionx+j][posiciony]!=undefined){
								salida=0;							
							}						
							if (posiciony>0){
								if (tablero[posicionx+j][posiciony-1]!=undefined){
									salida=0;																
								}				
							}	
							if (posiciony<(casillas_y-1)){
								if (tablero[posicionx+j][posiciony+1]!=undefined){
									salida=0;																
								}				
							}	
						
							
						}	
					}
					
					if (horizontal){
							if (posiciony>0){
								if (tablero[posicionx][posiciony-1]!=undefined){
									salida=0;																
								}				
							}							
							if (posiciony+longitud<(casillas_y-1)){
								if (tablero[posicionx][posiciony+1+longitud]!=undefined){
									salida=0;																
								}				
							}														
					}
					else{
							if (posicionx>0){
								if (tablero[posicionx-1][posiciony]!=undefined){
									salida=0;																
								}				
							}							
							if (posicionx+longitud<(casillas_x-1)){
								if (tablero[posicionx+1+longitud][posiciony]!=undefined){
									salida=0;																
								}				
							}							
					}
			return salida;
		
		}
		
		
		
		function llenartablero(){
			var conseguido = true;
			
			for (i=0;i <palabrasSopa.length;i++ ){
				 var intentos_posicionado=0;
				 var max_intentos_posicionado=20;
				 var horizontal = i%2;;
				 var palabra = palabrasSopa[i];
				 var longitud = palabra.length;
				 var maximox = casillas_x - longitud +1 ;
				 var maximoy = casillas_y - longitud +1;
				 var posicionado= false;
				 var pruebas = new Array(casillas_x);
				 while(!posicionado){				
					var posicionx=Math.floor((Math.random()*maximox));
					var posiciony=Math.floor((Math.random()*maximoy));
					intentos_posicionado = intentos_posicionado +1;					
					
					var vacio=1;
					vacio = comprobarLibre(posicionx,posiciony,longitud,horizontal)
					
					if (vacio==1){				
							var posicioninsertarx=-1;
							var posicioninsertary=-1;
							for (j=0;j <longitud;j++ ){
								if (horizontal){
									posicioninsertarx = posicionx;
									posicioninsertary = posiciony+j;
								
								}
								else{
									posicioninsertarx = posicionx+j;
									posicioninsertary = posiciony;
								
								}
								tablero[posicioninsertarx][posicioninsertary]=palabra.substr(j,1);
								respuestasSopa.push(posicioninsertarx+"#"+posicioninsertary+"#"+palabra+"#"+horizontal+"#"+i);
							}
						
							posicionado =true;
					}
					
					if (intentos_posicionado== max_intentos_posicionado){
					posicionado = true;
					conseguido= false;
					
					}						
											
				}
				if 	(!conseguido){
				 respuestasSopa = []
					for (i=0;i <casillas_x;i++ ) 
					{ 
						tablero[i]=new Array(casillas_y); 
					}
					break;						
				}	
			}
			return conseguido;
			
			
				
		}
			
		function seleccionarletra(casilla){
			
			if ($(casilla).hasClass("seleccionado")){
				$(casilla).removeClass("seleccionado");
				$(casilla).removeClass("error");
				$(casilla).removeClass("acierto");
			}
			else{
				$(casilla).addClass("seleccionado");
			}
		}
		
		function pintartablero(){			
			var salida ="";
			var table = $('<table></table>').attr( 'id','tablero');
			for (i=0;i <casillas_x;i++ ){
                row = $('<tr></tr>').attr( 'id','col'+i).addClass("col");
                for (j=0;j<casillas_y;j++ ){
					var row1;
					var valor;
					if (tablero[i][j]!=undefined){						
						valor = tablero[i][j].toUpperCase();						
						row1 = $('<td></td>').addClass('fila posicionada').text(valor).attr('id','casilla'+i+"_"+j);
					}
					else{
						//addControl(Math.floor((Math.random()*caracterespermitidos.length)))
						valor = caracterespermitidos.substr(Math.floor((Math.random()*caracterespermitidos.length)),1);
						row1 = $('<td></td>').addClass('fila').text(valor);
						
						
					}
					
					row1.click(function(){seleccionarletra($(this))})
					table.append(row);
					row.append(row1);
						
					
                }
            }
	
			$('#sopaletras').append(table);
		}
