var debugWin;
var ctrlPressed = false;
var teclaCtrl = 17, teclaC = 96;

$(document).keydown(function(e){	
  if (e.keyCode == teclaCtrl)
    ctrlPressed = true;

  if (ctrlPressed && (e.keyCode == teclaC))
    showControl();
});

$(document).keyup(function(e){
  if (e.keyCode == teclaCtrl)
    ctrlPressed = false;
});

function creaDivControl() {		
	$('body').prepend('<div id="botDebug"></div>');		
	$('#botDebug').css({
		position:"absolute",top:0,left:0,width:10,height:10
	}).html("<a onclick='javascript:showControl();'><div style='width:10px;height:10px;position:absolute;top:0;left:0'></div></a>");
}

function addControl(txt){
	elDebug = $('#debugerTxt');
	if(elDebug){
		$('#debugerTxt').append(txt +"<br/>");
	}
	try{
		if (typeof console == "object") {
			console.info(txt);
			/*console.info('information');
			console.warn('some warning');
			console.error('some error');
			console.assert(false, 'YOU FAIL');*/
		}
	}catch(e){}
}

function showControl(){	
	if($('#debugger').length<=0){	
		$("body").append ('<div id="debugger" style="" class="debugger"></div>');
		$("#debugger").hide();
		$("#debugger").load("../src/debugger.html", function(response, status, xhr) {
		  if (status == "error") {
			var msg = "Error!, algo ha sucedido: ";
			alert(msg + xhr.status + " " + xhr.statusText);
		  }
	});
	}	
	showDiv("debugger");	
}

function resetDebugger(){
	$('#debugerTxt').empty();
}

function sendSco(){
	var param = $('#selectValScorm').value;
	var value = $('#jsTxtVal');
	if($('#selectScorm').value == 1){
		addControl (doLMSSetValue(param));		
	}
	if($('#selectScorm').value == 2){
		addControl(doLMSSetValue(param, value));		
	}
}

function sendJs(){	
	//addControl("debug SendJs");
	var g = $('#jsTxtVal').val();
	strFun = 'addControl';
	var strVal = eval(g);
	var fn = window[strFun]; 
	fn(strVal);
	return true;
}

function callFunction(){
	//addControl("callFunction")
	var f = $('#funTxt');
	var strFun = f.value;
	var strParam = "this is the parameter"; 
	var fn = window[strFun]; 
	fn();
	return true;
}

function borrar(obj) {
  fi = $('#debugger'); // 1 
  fi.removeChild(document.getElementById(obj)); // 10
}

function pageName(){	
	var a = location.href;
	s = a.lastIndexOf("?");
	p = a.lastIndexOf("unidad");
	nombrepag = a.substring(s, p);
	return nombrepag;
}

//SCORM REFS ///////////////////////////////////////////////////////////////////////
function showControlVars(){
	nombre = doLMSGetValue("cmi.core.student_name");
	var str = nombre.split(",");
	var txtVars = " SCORM +++++++++++++";
	txtVars += "student_name: "+str[1]+" "+str[0]+"<br/>";
	txtVars += "lesson_status: "+estadoCurso()+"<br/>";
	txtVars += "score_raw: "+getNota()+"<br/>";
	txtVars += "Objetivos: " + showOjetives() + "<br/>";
	txtVars += "suspend_data: "+getSuspendData() +"<br/>";
	addControl(txtVars);
}
function studentId(){	
	var student = doLMSGetValue("cmi.core.student_id");	
	return student;
}
function estadoCurso(){
	estado = doLMSGetValue("cmi.core.lesson_status"); 
	return estado;
}
function getNota(){
	var nota = doLMSGetValue("cmi.core.score.raw");
	return nota;
} 
function showOjetives(){
	var objs = doLMSGetValue('cmi.objectives._count')
	return objs;
}function getSuspendData(){
	var suspenddata = doLMSGetValue('cmi.suspend_data');	
	return suspenddata;
}function getObjetives(){
	var numObjs = doLMSGetValue('cmi.objectives._count');
	for (i=0;i<numObjs;i++){
		estado = doLMSGetValue('cmi.objectives.'+i+'.status');
		id = doLMSGetValue('cmi.objectives.'+i+'.id');
		score = doLMSGetValue('cmi.objectives.'+i+'.score.raw');
	}
}
function getDebugSco(){
	var scoId = $('select[name="scormParams"]').val();	
	if(scoId == 'cmi.objectives._count'){
		getObjetives();
	}else{
		sco = doLMSGetValue(scoId);
		return sco;
		}
}
function setDebugSco(){
	var scoId = $('select[name="scormParams"]').val();
	var val = $('input[name="scormVal"]').val();
	sco = doLMSSetValue(scoId,val);
	addControl(scoId +' : ' + val + ' : ' + sco)
	return sco;
}
function getScoValue(_sco){
	var scoRefs = new Array("estado","nombre","num Objs","id Obj");	
	var z=doLMSGetValue("cmi.objectives._count");	
	var scoValues = new Array('cmi.core.lesson_status','cmi.core.student_name','cmi.objectives._count','cmi.objectives.'+z+'.id',objetivo);
	for(var i=0;i<scoRefs.length;i++){
		if(_sco==scoRefs[i]){
			_sco = scoValues[i];	
		}
	}
	return "_sco : " + doLMSGetValue(_sco);
}
function setScormDebug(pCallFunction, pParam, pReturnValue) {
	if(debugWindow){
		if(pCallFunction != 'LMSGetValue'){
			if(doLMSGetLastError()!=0 || pReturnValue!= 'true') {
				sScormDebug += "<span style='color:red'>"	
			}else{
				sScormDebug += "<span style='color:green'>"	
				}		
			sScormDebug += "Llamada: " + pCallFunction + "('" + pParam+ "')<br>";
			sScormDebug += "Retorno: " + pReturnValue + "<br>";
			sScormDebug += "Error: " + doLMSGetLastError() + "<br>";
			sScormDebug += "----------------------------------------------------------<br/>";
			sScormDebug += "</span>"	
		}
		debugWindow.document.getElementsByName('body').innerHTML += sScormDebug;
		debugWindow.focus();
	}
}
var debugWindow;		
function getScormDebugString (){	
	if(typeof(window['debugWindow']) == 'undefined' || window['debugWindow'].closed ){
		debugWindow = window.open( "","debugWindow", "location=no,menubar=yes,scrollbars=yes,width=500,height=500,resizable=yes");
		var lista = document.getElementsByTagName('h2');
		if(lista=='undefined'){lista="";}
		//alert(lista[0].innerHTML)
		//setTimeout(function(){
		var style = '<style type="text/css"><!--body,td,th {font-size: 11px;}--></style>'
		debugWindow.document.write('<html><head>'+style+'<title>debugWindow</title></head><script>/*window.opener.onbeforeunload = function(){window.close();}*/</script><body onBlur="self.focus()" style="padding:20px;background-color:#FFF">'+ lista[0].innerHTML + ' ('+pageName()+')<br/></body></html>');
		debugWindow.focus();
		//},1000);
	}else{
			debugWindow.document.getElementsByName('body').innerHTML += sScormDebug;
			debugWindow.focus();
	}				
}
////////////////////////////////////////////////////////////////////////////////////////
function showBrowserInfo(){
	var browserInfo="";
	$.each( navigator, function( i, val ) {
	// browserInfo += "<div>" + i + " : <span>" + val + "</span></div>";
	});	
	browserInfo += '<div><b>appName</b> : '+navigator.appName+'</div>';
	browserInfo += '<div><b>appCodeName</b> : '+navigator.appCodeName+'</div>';
	browserInfo += '<div><b>appVersion</b> : '+navigator.appVersion+'</div>';
	browserInfo += '<div><b>OS</b> : '+navigator.oscpu+'</div>';
	browserInfo += '<div><b>platform</b> : '+navigator.platform+'</div>';
	browserInfo += '<div><b>userAgent</b> : '+navigator.userAgent+'</div>';
	browserInfo += '<div><b>language</b> : '+navigator.language+'</div>';
	browserInfo += '<div><b>cookieEnabled</b> : '+navigator.cookieEnabled+'</div>';
	browserInfo += '<div><noscript><b>Javascript disabled</noscript><b>Javascript</b>: enabled</b></div>';
	browserInfo += '<div><b>OnLine</b> : '+navigator.onLine+'</div>';
	addControl(browserInfo);
}