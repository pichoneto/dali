Dali.Plugins["RelacionaAll"] = function (base) {

    var fallbackUrlImage = "http://i.imgur.com/ilFsT33.gif";

    var calculatePositions = function(relAllXML){
        var dragTxtWidth = relAllXML.attr('anchoDrag');
        var dropTxtWidth = relAllXML.attr('anchoDrop');
        var solDrag = relAllXML.attr('sol').split(",");
        var dropWidth = 0;
        var dragWidth = 0;

        for (var i = 0; i < base.getState().dragItemCount; i++) {
            var dragItem = $("#drag" + i);
            var dragTxtItem = $("#dragTxt" + i);

            dragTxtItem.css("width", dragTxtWidth);
            dragItem.css("width", dragWidth);
            dragItem.css("height", dragWidth);
            var posT = ((dragTxtItem.height() / 2) - (dragItem.height() / 2));
            var posL = dragItem.attr('posT', dragTxtItem.position().top - ((dragTxtItem.height() / 2) - (dragItem.height() / 2)));
            dragItem.css("top", posT);
            dragItem.attr('posL', posL); //dragItems[i].position().left
            dragItem.attr('posT', posT); //dragItems[i].position().top
        }
        for (var i = 0; i < base.getState().dropItemCount; i++) {
            var dropItem = $("#drop" + i);
            var dropTxtItem = $("#dropTxt" + i);

            dropTxtItem.css("width", dropTxtWidth);
            //dropTxtItem.css("height", dropTxtItem.height());
            dropItem.css("width", dropWidth);
            dropItem.css("height", dropWidth);
            var posT = ((dropTxtItem.height() / 2) - (dropItem.height() / 2) );
            dropItem.css("top", posT);
        }
        var dragsH = $('#drags').outerHeight(true);
        var dropsH = $('#drops').outerHeight(true);
        var _div;
        if (dropsH > dragsH) {
            var posTop = (dropsH - dragsH) / 2;
            _div = $('#drags');
        } else {
            var posTop = (dragsH - dropsH) / 2;
            _div = $('#drops');
        }
        if (posTop > 15) {
            _div.css({
                margin: posTop + 'px 10px 10px 10px'
            });
        }
        $('#ejercicioBase').css({
            margin: '0 auto 0 auto',
            width: $('#drags').outerWidth(true) + $('#drops').outerWidth(true) + 20 + 'px'
        });

        for (var i = 0; i < solDrag.length; i++) {
            jsPlumb.connect({
                source: "drag" + i,
                target: "drop" + solDrag[i],
                anchors: ["Right", "Left"],
                endpoint: ["Dot", {radius: 17}],
                endpointStyle: {fillStyle: "green", strokeStyle: "green"},
                connectorStyle: {strokeStyle: "green", lineWidth: 2},
                paintStyle: {strokeStyle: "green", lineWidth: 4},
                connector: "Straight"
            });
        }
    }

    var imagesLoaded = 0;
    var loadImages = function(relAllXML){
        var dragImgs = base.getState().dragImgs;
        var dropImgs = base.getState().dropImgs;
        var totalImages = Object.keys(dropImgs).length + Object.keys(dragImgs).length;

        if (totalImages > 0) {
            for (var i = 0; i < Object.keys(dragImgs).length; i++) {
                var key = Object.keys(dragImgs)[i];
                loadImage("#imgDrag" + key, totalImages, relAllXML, dragImgs[key]);
            }

            for (var i = 0; i < Object.keys(dropImgs).length; i++) {
                var key = Object.keys(dropImgs)[i];
                loadImage("#imgDrop" + key, totalImages, relAllXML, dropImgs[key]);
            }
        } else {
            calculatePositions(relAllXML);
        }
    }

    var loadImage = function(selector, totalImages, relAllXML, img){
        $(selector).load(function () {
            imagesLoaded++;
            if (imagesLoaded >= totalImages) {
                calculatePositions(relAllXML);
            }
        }).attr('src', img).error(function() {
            img = fallbackUrlImage;
            loadImage(selector, totalImages, relAllXML, img);
        });
    }

    return {
        getConfig: function () {
            return {
                name: 'RelacionaAll',
                category: 'exercises',
                needsConfigModal: true,
                needsXMLEdition: true,
                icon: 'timeline'
            }
        },
        getToolbar: function () {
            var toolBar = {
                main: {
                    __name: "Main",
                    accordions: {
                        image: {
                            __name: "Imagen",
                            icon: 'image',
                            buttons: {
                                hasImage: {
                                    __name: 'Tiene Imagen',
                                    type: 'checkbox',
                                    value: 'unchecked'
                                },
                                url: {
                                    __name: 'URL',
                                    type: 'text',
                                    autoManaged: false,
                                    value: 'http://nemanjakovacevic.net/wp-content/uploads/2013/07/placeholder.png'
                                }
                            }
                        }
                    }
                }
            }

            toolBar.main.accordions.solutions = {__name: "Soluciones", icon:'done', buttons: {}};
            var opt = [];
            for (var i = 1; i <= base.getState().nAnswers; i++) {
                opt.push({label: "" + i, value: "" + i});
            }
            for (var i = 0; i < base.getState().nQuestions; i++) {
                toolBar.main.accordions.solutions.buttons["RAmatch" + i] = {
                    __name: 'Respuesta correcta a pregunta ' + (i + 1),
                    type: 'select',
                    value: ["1"],
                    multiple: true,
                    options: opt,
                    autoManaged: false

                }
            }
            return toolBar;
        },
        getInitialState: function () {
            return {__xml: 'pathToFile', dragItemCount: 0, dropItemCount: 0, dragImgs: [], dropImgs: []};
        },
        getRenderTemplate: function (state) {
            var relAllXML = $(state.__xml.childNodes[0].childNodes);

            var dragElements = new Array();
            var dropElements = new Array();
            var dragImgs = {};
            var dropImgs = {};
            var numElements = 0;
            var enunciado = relAllXML.attr('enunciado');
            var img = relAllXML.attr('img');
            var instrucciones = relAllXML.attr('instrucciones') + '<span style="text-align:center;display:block;">';
            var botCorregir = 'onclick="javascript:corrigeDragAndDrop()"';

            jsPlumb.detachEveryConnection();

            if (img != undefined) {
                instrucciones += '<img class="imgPpal" />';
            }
            instrucciones += '</span>';

            relAllXML.find("DRAG").each(function () {
                dragElements[numElements] = $(this).text();
                var dragImg = $(this).attr('img');
                if (dragImg != undefined) {
                    dragImgs[numElements] = $(this).attr('img');
                }
                numElements++;
            });

            numElements = 0;
            relAllXML.find("DROP").each(function () {
                dropElements[numElements] = $(this).text();
                var dropImg = $(this).attr('img');
                if (dropImg != undefined) {
                    dropImgs[numElements] = $(this).attr('img');
                }
                numElements++;
            });

            var drags = "";
            for (var i = 0; i < dragElements.length; i++) {
                var items = '<div id="dragTxt' + i + '" class="boxDrag" rel="' + i + '">' + dragElements[i] + '</div>';
                if (dragImgs[i] != undefined) {
                    items = '<div id="dragTxt' + i + '" class="boxDrag" rel="' + i + '"><img id ="imgDrag' + i + '" class="dragImg" />' + dragElements[i] + '</div>';
                }
                items += '<div id="drag' + i + '" class="draggable" rel="' + i + '"></div>';
                drags += items;
            }

            var drops = "";
            for (var i = 0; i < dropElements.length; i++) {
                var items = '<div id="drop' + i + '" class="droppable" rel="' + i + '"></div>';
                if (dropImgs[i] != undefined) {
                    items += '<div id="dropTxt' + i + '" class="boxDrop" rel="' + i + '"><img id="imgDrop' + i + '" class="dragImg"/>' + dropElements[i] + '</div>';
                } else {
                    items += '<div id="dropTxt' + i + '" class="boxDrop" rel="' + i + '">' + dropElements[i] + '</div>';
                }
                drops += items;
            }

            state.dragItemCount = dragElements.length;
            state.dropItemCount = dropElements.length;
            state.dragImgs = dragImgs;
            state.dropImgs = dropImgs;

            var template =
                '<table width="100%" border="0" cellspacing="0" cellpadding="0"> ' +
                    '<tr>' +
                        '<td>' +
                            '<div id="enunciadoEjer">' + enunciado + '</div>' +
                            '<div id="instruccionesEjer">' + instrucciones + '</div>' +
                            '<div id="resultados"></div>' +
                            '<div id="ejercicio">' +
                                '<div id="ejercicioBase"><div id="drags" class="drags">' +
                                    drags +
                                '</div><div id="drops" class="drops">' +
                                    drops +
                                '</div></div>' +
                            '</div>' +
                            '<div id="corregir">' +
                                '<input name="corrige" id="botCorregir" value="Corregir" class="bot" type="button" ' + botCorregir + '"/>' +
                            '</div>' +
                            '<div id="paginacion"></div>' +
                        '</td>' +
                    '</tr>' +
                '</table>';
            return template;
        },
        getConfigTemplate: function (state) {
            var template = '<div class="col-xs-12">' +
                '<input type="file" id="file" onchange="$dali$.xmlToState(event,this)" /> <div id="formularioXml"></div> </div>';
            return template;

        },
        afterRender: function (element, state) {
            var relAllXML = $(state.__xml.childNodes[0].childNodes);

            var imgsLoaded = 0;
            var instImgsNum = $("#instruccionesEjer").find('img');
            instImgsNum.each(function () {
                $(this).attr('src', relAllXML.attr('img'));
                $(this).load(function (a, b, c) {
                    imgsLoaded++;
                    if (imgsLoaded >= instImgsNum.length) {
                        loadImages(relAllXML);
                    }
                }).error(function() {
                    $(this).attr('src', fallbackUrlImage);
                });

            });
            if (instImgsNum.length <= 0) {
                loadImages(relAllXML);
            }
        },
        xmlToState: function (event) {
            var files = event.target.files;
            var reader = new FileReader();

            reader.onload = function () {
                var parsed = new DOMParser().parseFromString(this.result, "text/xml");
                var auxXml = parsed;

                var x = parsed.getElementsByTagName('ITEMS');
                for (j = 0; j < x.length; j++) {
                    var auxX = auxXml.getElementsByTagName("ITEMS")[j];
                    for (n = 0; n < x[j].childNodes.length; n++) {
                        auxX.removeChild(auxX.childNodes[n]);
                    }
                }

                var y = parsed.getElementsByTagName('ITEM');
                for (i = 0; i < y.length; i++) {
                    var aux = auxXml.getElementsByTagName("ITEM")[i];
                    for (n = 0; n < y[i].childNodes.length; n++) {
                        aux.removeChild(aux.childNodes[n]);
                    }
                    for (n = 0; n < y[i].childNodes.length; n++) {
                        if (auxXml.getElementsByTagName("ITEM")[i].childNodes[n].nodeType == 8) {
                            auxXml.getElementsByTagName("ITEM")[i].removeChild(auxXml.getElementsByTagName("ITEM")[i].childNodes[n]);
                        }
                    }
                }

                auxXml.normalize();
                base.setState('__xml', auxXml);
            };

            reader.readAsText(files[0]);
        }
    }
}