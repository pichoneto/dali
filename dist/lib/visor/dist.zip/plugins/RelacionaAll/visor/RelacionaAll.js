Dali.Visor.Plugins["RelacionaAll"] = function () {
    return {
        getRenderTemplate: function (state) {
            return "<iframe src='./exercises/index.html' ejerType='relAll' myXmlFile='" + state["__xml_path"] + "' style=\"width: 100%; height: 100%; border: 0\"></iframe>";
        }
    }
}
