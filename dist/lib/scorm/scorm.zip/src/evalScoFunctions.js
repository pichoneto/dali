//	JavaScript Document
//	Luis Miguel del Corral
//	Version:	1.0
//	Fecha:	27 de Junio 2016
/*
	Datos:	

*/

function checkNumTries() {
    if (typeof evalDiagnostica != 'undefined') {
        numIntentos = 1;
    }
    if (scormConn) {} else {
        numIntentos = 1;
    }
    var numObjetives = doLMSGetValue('cmi.objectives._count');
    var notaDef = doLMSGetValue('cmi.core.score.raw');
    for (i = 0; i < numObjetives; i++) {
        var estadoObj = doLMSGetValue('cmi.objectives.' + i + '.status').charAt(0);
        if (estadoObj != 'n' && estadoObj != 'N') {
            numTries++;
        }
    }
    if (notaDef >= NotaCorte) {
        notaDef = '<span class="notaOk">' + notaDef + '</span>';
        var imgNota = '<img src="../images/correcionOk.jpg" style="vertical-align:middle;"/>'
    } else {
        notaDef = '<span class="notaKo">' + notaDef + '</span>';
        var imgNota = '<img src="../images/correcionKo.jpg" style="vertical-align:middle;"/>';
    }
    msg1 = "Atenci\u00f3n. Vas a comenzar la evaluaci\u00f3n.</br>Recuerda que tienes " + numIntentos + " intento/s.";

    if (typeof evalDiagnostica != 'undefined') {
        msg1 = "Atenci\u00f3n. Vas a comenzar la evaluaci\u00f3n diagn\u00f3stica.</br>Recuerda que tienes " + numIntentos + " intento.";
    }
    msg2 = "Te quedan " + (numIntentos - numTries) + " de " + numIntentos + " intentos."
    msg3 = "Recuerda que es tu \u00faltimo intento.</br>Tu nota anterior fue de " + notaDef + " sobre " + scoreMax + ".</br>Tendremos en cuenta la nota m\u00e1s alta.";
    msg4 = "Ya has agotado los " + numIntentos + " intentos.</br>Tu nota final es de " + notaDef + " sobre " + scoreMax;

    if (numTries >= numIntentos) {
        saveData = false;
        alertMsg = msg4;
    } else {
        saveData = true;
        if (typeof cuentaNum != 'undefined') {
            createCrono();
        }
        if (numTries == 0 || numTries == "") {
            alertMsg = msg1;
        } else {
            if (numTries >= (numIntentos - 1)) {
                showSolution = true;
                alertMsg = msg3;
            } else {
                alertMsg = msg2;
            }
        }
    }

    createAlert('<div style="float:left;height:100%;margin-right:5px;position:absolute;z-index:-1;">' + imgNota + '</div><div style="margin-left:50px;float:left;height:100%;width:auto">' + alertMsg + '</div>');
    showLastResult();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// MUESTRO EL ULTIMO RESULTADO OBTENIDO  /////////////////////////////////////////////////////////////////////
function showLastResult() {
    var estado = doLMSGetValue('cmi.core.lesson_status').charAt(0).toLowerCase();
    var notaant = doLMSGetValue('cmi.core.score.raw');

    if (estado != ESTADO_NO_INTENTADO.charAt(0).toLowerCase() && estado != "" && notaant != "") {
        if (notaant >= NotaCorte) {
            notaant = "<span class='notaOk'>" + notaant + "</span>";
            imgResult = '../images/correcionOk.jpg';
            msnResult = '<span class="notaOk">&nbsp;&nbsp;APTO</span>';
            if (typeof evalDiagnostica != 'undefined') {
                msnResult = '<span class="notaTutor">El tutor tendrá en cuenta tu nivel en la impartición del curso.</span>';
            }
        } else {
            imgResult = '../images/correcionKo.jpg';
            msnResult = '<span class="notaKo">&nbsp;&nbsp;NO APTO</span>';
            notaant = "<span class='notaKo'>" + notaant + "</span>";
            if (typeof evalDiagnostica != 'undefined') {
                msnResult = '<span class="notaTutor">El tutor tendrá en cuenta tu nivel en la impartición del curso.</span>';
            }
        }
        if (numTries < numIntentos) {
            msgText = "<img src='../images/" + imgResult + "' hspace='0' align='left'/>&nbsp;&nbsp;<B>Tu mejor puntuaci&oacute;n fue de " + notaant + " punto/s sobre 10 despu&eacute;s de " + numTries + " intento/s.</B><br/>";
        } else {
            msgText = "<img src='../images/" + imgResult + "' hspace='0' align='left'/>&nbsp;&nbsp;<B>Tu puntuaci&oacute;n final es de " + notaant + " punto/s sobre 10 despu&eacute;s de " + numTries + " intento/s.</B><br/>";
        }
        if (numTries < numIntentos) {
            msgText += "&nbsp;&nbsp;<B>Tienes " + (numIntentos - numTries) + " intento/s m&aacute;s.</B>";
        } else {
            msgText += "&nbsp;&nbsp;<B>Has agotado el n&uacute;mero de intentos.</B>";
        }
    } else {
        msgText = "<img src='../images/check_nulo.gif' hspace='0' align='left'/>&nbsp;&nbsp;<B>Todav&iacute;a no has realizado la evaluaci&oacute;n.<br/>&nbsp;&nbsp;Recuerda que tienes dos intentos para superarla.</B>";
        if (typeof evalDiagnostica != 'undefined') {
            msgText = "<img src='../images/check_nulo.gif' hspace='0' align='left'/>&nbsp;&nbsp;<B>Todav&iacute;a no has realizado la evaluaci&oacute;n diagn&oacute;stica.<br/>&nbsp;&nbsp;Recuerda que tienes solo 1 intento para superarla.</B>";
        }
    }
    $("#txtResult").html(msgText);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// MUESTRO LA PUNTUACIÓN OBTENIDA AL CORREGIR/////////////////////////////////////////////////////////////////
function showExResults() {
    if (scormConn) {
        var notaant = doLMSGetValue('cmi.core.score.raw');
    } else {
        notaant = 0;
    }
    nota = roundNumber(nota);
    if (nota >= NotaCorte) {
        imgResult = '<img src="../images/correcionOk.jpg" hspace="0" align="absmiddle"/>';
        msnResult = '<span class="notaOk">&nbsp;&nbsp;APTO</span>';
        notaTxt = "<span class='notaOk'>" + nota + "</span>";
        if (typeof evalDiagnostica != 'undefined') {
            imgResult = '';
            msnResult = '<span class="notaTutor">El tutor tendrá en cuenta tu nivel en la impartición del curso.</span>';
        }
    } else {
        imgResult = '<img src="../images/correcionKo.jpg" hspace="0" align="absmiddle"/>';
        msnResult = '<span class="notaKo">&nbsp;&nbsp;NO APTO</span>';
        notaTxt = "<span class='notaKo'>" + nota + "</span>";
        if (typeof evalDiagnostica != 'undefined') {
            imgResult = '';
            msnResult = '<span class="notaTutor">El tutor tendrá en cuenta tu nivel en la impartición del curso.</span>';
        }
    }

    resOk = "<span class='notaOk'>" + resOk + "</span>";
    resKo = "<span class='notaKo'>" + resKo + "</span>";
    resNo = "<span class='notaNo'>" + resNo + "</span>";
    msg = imgResult + msnResult + "<p>Respuestas correctas: " + resOk + "<br/>Respuestas incorrectas: " + resKo + "<br/>No contestadas: " + resNo + ".";
    msg += "<br/><b>Tu nota ha sido de " + notaTxt + " punto/s sobre 10.</b></p>";
    if (test) {
        msg += "<br/><br/><spam style='color:#4e88db'><b><i>Observa las respuestas correctas y, en su caso, repasa los contenidos asociados para reforzarlos.</i></b></spam>";
    }

    if (numTries >= numIntentos) {
        notaDef = notaant;
        if (notaDef >= NotaCorte) {
            notaDef = "<span class='notaOk'>" + notaDef + "</span>";
        } else {
            notaDef = "<span class='notaKo'>" + notaDef + "</span>";
        }
        msg += "<br><b>Tu puntuaci\u00f3n final es de " + notaDef + " sobre 10 puntos.</b>";
    }
    $("#txtResult").html(msg);
    $("#resultado").addClass("resultado");
}

////////////////////////////////////////////////////////////////////////////////////////////////
//Mostramos LAS RESPUESTAS DEL EJERCICIO después de CORREGIR ///////////////////////////////////
function showResultDiv(name) {
    if (name == "pregunta" || name == "J") {
        estilo = "texto_sol";
    }
    if (name == "debugger") {
        $('#debugger').hide();
    }
    for (i = 0; i < 60; i++) {
        div = $('#' + name + i);
        if (div.length > 0) {
            div.addClass(estilo);
            if (!div.is(':visible')) {
                div.show();
            } else {
                div.hide();
            }
        }
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Cuándo no se ha realizado el ejercicio....//////////////////////////////////////////////////////
function onUnloadEvalScormEvent() {
    if (scormConn) {
        if (hacorregido == false) {
            var estado = doLMSGetValue('cmi.core.lesson_status').charAt(0);
            var estado01 = ESTADO_NO_INTENTADO.charAt(0).toLowerCase();
            var estado02 = ESTADO_INCOMPLETO.charAt(0).toLowerCase();
            var z = doLMSGetValue("cmi.objectives._count");

            if (evaluacion || typeof testInicial != 'undefined' || typeof simulador != 'undefined') {
                if (estado == estado01 || estado == estado02) {
                    doLMSSetValue('cmi.core.lesson_status', ESTADO_COMPLETADO);
                    doLMSSetValue('cmi.objectives.' + z + '.id', objetivo);
                    doLMSSetValue('cmi.objectives.' + z + '.status', ESTADO_NO_INTENTADO);
                    doLMSSetValue('cmi.objectives.' + z + '.score.raw', '0');
                    doLMSSetValue('cmi.objectives.' + z + '.score.max', scoreMax);
                    doLMSSetValue('cmi.objectives.' + z + '.score.min', '0');
                    doLMSCommit();
                }
            }
            if (test) {
                doLMSSetValue('cmi.core.lesson_status', ESTADO_COMPLETADO);
                doLMSSetValue('cmi.objectives.' + z + '.id', objetivo);
                doLMSSetValue('cmi.objectives.' + z + '.status', ESTADO_NO_INTENTADO);
                doLMSSetValue('cmi.objectives.' + z + '.score.raw', '0');
                doLMSSetValue('cmi.objectives.' + z + '.score.max', scoreMax);
                doLMSSetValue('cmi.objectives.' + z + '.score.min', '0');
                doLMSCommit();
            }
            hacorregido = true;
            endScorm();

        }
    } else {
        showError(ERROR_SAVE_EVAL);
    }

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// CORRECCIÓN EJERCICIO TIPO TEST tanto Evaluación como test. //////////////////////////////////////////////////////////////////////////////
var nota = 0;

function corregirEval(_val, _ok) {
    if (typeof cuentaNum != 'undefined') {
        clearInterval(cuentaAtrasTimer);
    }
    showPreloader('Corrigiendo...');
    addControl('# corregirEval  # <b>' + objetivo + '</b>');
    addControl("_val:" + _val);
    addControl("_ok:" + _ok);

    var interactionsArr = new Array();
    var responsesArr = new Array();
    hacorregido = true;
    nota = 0;
    var valida = '';
    var k = 0;
    resOk = 0;

    addControl('saveData ' + saveData);
    document.EF.correccion.src = "../images/pixel_transp.gif";
    document.getElementById('correccion').style.visibility = 'hidden';

    // manejo PDF SOLUCION
    if (showSolution || saveData == false) {
        if (!document.getElementById("solPdf")) {} else {
            elementoSolPdf = document.getElementById("solPdf");
            elementoSolPdf.className = "texto_sol";
        }
    }

    //chekeo las respuestas		
    for (k = 1; k <= res.length; k++) {
        valida = res[k - 1];
        var valor = '';
        var j = 0;
        var imagen = eval('document.EF.G' + k);

        for (j = 0; j <= 10; j++) {
            if (eval('document.EF.r' + k + '[' + j + ']')) {
                if (eval('document.EF.r' + k + '[' + j + '].checked')) {
                    valor = valor + eval('document.EF.r' + k + '[' + j + '].value');
                }
            }
        }
        interactionsArr.push(valor);
        if (valor == valida) {
            resOk++;
            responsesArr.push(1);
            nota = nota + (10 / res.length);
            imagen.alt = "verdadero";
            imagen.src = "../images/check_true.gif";
        } else {
            // si es incorrecta			
            if (valor != "") {
                resKo++;
                responsesArr.push(0);
                imagen.alt = "falso";
                imagen.src = "../images/check_false.gif";
            } else {
                // si no ha contestado					
                resNo++;
                responsesArr.push(undefined);
                imagen.alt = "nulo";
                imagen.src = "../images/check_nulo.gif";
            }
        }

    }

    if (nota >= scoreMax) {
        nota = scoreMax;
    } else {
        nota = nota;
    }
    if (nota < 0) {
        nota = 0;
    }

    var notaf = nota.toString();
    notaf = notaf.replace(',', '.');

    if (test == true && justExist == true) {
        showResultDiv('J');
        showResultDiv('pregunta');
        addControl("Muestra Sol TEST")
    }
    if (evaluacion == true) {
        if (numTries >= (numIntentos - 1)) {
            showResultDiv('pregunta');
            showResultDiv('J');
            addControl("Muestra Sol EVAL")
        }
    }
    nota = nota = fix(nota, 2);
    showExResults();
    repeatExButton($("#resultado"));

    if (scormConn) {
        grabaejercicio(nota, interactionsArr.toString(), responsesArr.toString(), NotaCorte);
    } else {
        showError(ERROR_SAVE_EVAL);
        hidePreloader();
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FUNCION COMUN /Para GRABAR los datos SCORM de los EJERCICIOS ////////////////////////////////////////////////////////////////////////////
function grabaejercicio(_val, _inter, _resOk, _corte) {
    showPreloader('Corrigiendo...')
    addControl("# grabaejercicio en plataforma # <br/>Nota: " + _val);
    //addControl("_inter : " + _inter.length + "  " + _inter);
    //addControl("_resOk : " + _resOk.length + "  " + _resOk);

    hacorregido = true;
    var nota = 0;
    if (!theObjetive) {
        theObjetive = objetivo;
    }
    addControl("OBJETIVO : " + theObjetive);

    interVals = _inter.split(",");
    okVals = _resOk.split(",");
    //addControl("interVals : " + interVals.length + "  " + interVals);
    //addControl("okVals : " + okVals.length + "  " + okVals);

    // NOTA ///////////////////////////////////////////////////////
    nota = _val;
    if (nota >= scoreMax) {
        nota = scoreMax;
    } else {
        nota = nota;
    }
    if (nota < 0) {
        nota = 0;
    }
    nota = fix(nota, 2);
    var notaf = nota.toString();
    notaf = notaf.replace(',', '.');
    /////////////////////////////////////////////////////////////
    if (scormConn) {
        var estado = doLMSGetValue('cmi.core.lesson_status');
        var notaant = doLMSGetValue('cmi.core.score.raw');
        if (notaant == '') {
            notaant = 0;
        }
        if (saveData) {
            //if(nota>=_corte){ //Siempre marcamos como completado		
            doLMSSetValue('cmi.core.lesson_status', ESTADO_COMPLETADO);
            //}else{
            //doLMSSetValue('cmi.core.lesson_status','failed');
            //}	
            if (parseFloat(notaant) >= parseFloat(nota)) {
                doLMSSetValue('cmi.core.score.raw', notaant);
                //notaf = notaant;
            } else {
                doLMSSetValue('cmi.core.score.raw', notaf);
            }
            doLMSSetValue('cmi.core.score.max', scoreMax);
            doLMSSetValue('cmi.core.score.min', '0');
            // OBJETIVOS //////////////////////////////////////////////////
            var z = doLMSGetValue('cmi.objectives._count');
            doLMSSetValue('cmi.objectives.' + z + '.id', theObjetive);
            doLMSSetValue('cmi.objectives.' + z + '.score.raw', notaf);
            doLMSSetValue('cmi.objectives.' + z + '.score.max', scoreMax);
            doLMSSetValue('cmi.objectives.' + z + '.score.min', '0');

            if (nota >= NotaCorte) {
                var stadoObj = ESTADO_PASADO
                addControl(" -- PASSED --");
            } else {
                var stadoObj = ESTADO_FALLADO;
                addControl(" -- FAILED --")
            }
            doLMSSetValue('cmi.objectives.' + z + '.status', stadoObj);
            // INTERACCIONES //////////////////////////////////////////////	
            var numOk = 0;
            for (i = 0; i < interVals.length; i++) {
                var interactNo = 'P' + i;
                if (i < 10) {
                    interactNo = 'P0' + i;
                }
                if (interVals[i] != "undefined") {
                    var n = doLMSGetValue("cmi.interactions._count");
                    doLMSSetValue('cmi.interactions.' + n + '.id', theObjetive + interactNo);
                    if (typeof _xmlFile != undefined) {
                        doLMSSetValue('cmi.interactions.' + n + '.type', 'fill-in');
                    } else {
                        doLMSSetValue('cmi.interactions.' + n + '.type', 'choice');
                    }
                    doLMSSetValue('cmi.interactions.' + n + '.weighting', 1);
                    doLMSSetValue('cmi.interactions.' + n + '.objectives.' + z + '.id', theObjetive);
                    doLMSSetValue('cmi.interactions.' + n + '.student_response', interVals[i]);

                    //addControl(" n : " + n + " OBJ: " + theObjetive + " - " + interVals[i] + " - " + okVals[i]);

                    if (okVals[i] == 1) {
                        var estadoInt = ESTADO_CORRECTO;
                        doLMSSetValue('cmi.interactions.' + n + '.result', ESTADO_CORRECTO);
                        numOk++;
                    } else {
                        var estadoInt = ESTADO_INCORRECTO;
                    }
                    doLMSSetValue('cmi.interactions.' + n + '.result', estadoInt);
                }
            }
            //doLMSCommit();		
            addControl("Nota corte:" + _corte + " NOTA" + _val + " NotaAnt:" + notaant + " OBJ:" + theObjetive);
        }
        endScorm();
    }

    $('body').animate({
        scrollTop: 0
    }, '500', 'swing', function() {
        hidePreloader();
    });
}




////////////////////////////////////////////////////////////////////////////////////////////////////////////
// creación del ejercicio TIPO TEST para EVALS Y TESTS

var justExist = false;
var letrasArr = new Array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "", "m");
var sol;
var evalVideoFiles = new Array();

function createEvalTest() {
    addControl("SAVEDATA:" + saveData);
    addControl('<br/>createEvalTest <b>' + res.length + '</b> preguntas');
    managePdfLinks();
    ko = false;
    var evalTxt = '';
    var videoNum = 0;
    for (i = 1; i <= res.length; i++) {
        if (isDefined("E" + i) == true) {
            //encima de la pregunta
            if (isDefined("TXT" + i) == true) {
                evalTxt += " <div class='opcion' style='width:98%;display:block;vertical-align:middle;float:left;margin-bottom:10px;margin-left:2%'>";
                evalTxt += eval("TXT" + i);
                evalTxt += "</div>";
            }
            if (isDefined("IMG" + i) == true) {
                var imagen = eval("IMG" + i);
                evalTxt += " <div class='opcion'>";
                evalTxt += "<div class='imagenEjer' style='text-align:center' id='IMG" + i + "'>";
                evalTxt += "<img src='" + imagen + "' style='width:100%;max-width:450px'/>";
                evalTxt += "</div>";
                evalTxt += "</div>";
            }
            if (isDefined("VIDEO" + i) == true) {
                var videoUrl = eval("VIDEO" + i);
                evalVideoFiles.push(videoUrl);
                evalTxt += createVideoDiv(videoNum);
                videoNum++;
            }
            if (isDefined("AUDIO" + i) == true) {
                var audioUrl = eval("AUDIO" + i);
                evalTxt += createAudioDiv(audioUrl);
            }
            evalTxt += "<div class='pregunta'>";
            evalTxt += "<div class='solucion'>";
            evalTxt += " <img src='../images/pixel_transp.gif' width='37' height='26' id='G" + i + "' name='G" + i + "'/>";
            evalTxt += " </div>";
            evalTxt += "<div class='opciones'>";
            evalTxt += "<div class='enunciado'>";
            evalTxt += i + ".- " + eval("E" + i);
            evalTxt += " </div>";



            //debajo de su enunciado
            if (isDefined("subVIDEO" + i) == true) {
                var subVideoUrl = eval("subVIDEO" + i);
                evalVideoFiles.push(subVideoUrl);
                evalTxt += createVideoDiv(videoNum);
                videoNum++;
            }
            if (isDefined("subAUDIO" + i) == true) {
                var subAudioUrl = eval("subAUDIO" + i);
                evalTxt += createAudioDiv(subAudioUrl);
            }
            var optionExists = false;
            for (j = 1; j <= letrasArr.length; j++) {
                //addControl("P"+i+""+j)
                if (isDefined("P" + i + "" + j) == true && !optionExists) {
                    evalTxt += "<div class='opcion'>";
                    evalTxt += "<div class='texto_resp'>";
                    evalTxt += "<input type='radio' name='r" + i + "' value='" + letrasArr[j - 1] + "' style='vertical-align: middle;margin-right:10px;'/>";
                    evalTxt += letrasArr[j - 1] + ".- " + eval("P" + i + "" + j);
                    evalTxt += "</div>";
                    evalTxt += "</div>";

                    if (res[i - 1] == letrasArr[j - 1]) {
                        sel = "P" + (i) + '' + (j);
                        sol = res[i - 1] + ".- " + eval(sel);
                    }
                } else {
                    optionExists = true;
                }
            }

            evalTxt += " <div class='opcion'>";
            evalTxt += "<div class='texto_sol' id='pregunta" + i + "'  style='display:none'>";
            evalTxt += "<p>CORRECTA:  " + sol + "</p>";
            evalTxt += "</div>";

            var justificacion = "";
            if (isDefined("J" + i) == true) {
                justExist = true;
                var justificacion = eval("J" + i);
                evalTxt += "<div class='texto_sol' id='J" + i + "' style='display:none'>";
                evalTxt += "<p>JUSTIFICACI&Oacute;N:  " + justificacion + "</p>";
                evalTxt += "</div>";
            }
            evalTxt += "</div>";
            evalTxt += " </div>";
            evalTxt += " </div>";
            //evalTxt += "<div class='clear'> </div>";		
            evalTxt += " </div>";
        } else {
            if (i > res.length) {
                addControl('<br/><b>ERROR :</b> pregunta ' + i + ' - no hay soluci&oacute;n en el array');
                ko = true;
            }
        }
    }
    if (!ko) {
        var botCorregir = '<div class="iconohover"><a href="#inicio"  target="_self" class="botDere" onclick="JavaScript:corregirEval();"><img src="../images/bot_correccion.gif" alt="corrección"  name="correccion" id="correccion" style="align:right"/></a></div>';
        document.getElementById('eval').innerHTML = evalTxt + botCorregir;
        if (evalVideoFiles.length > 0) {
            for (i = 0; i < evalVideoFiles.length; i++) {
                loadVideoContent(evalVideoFiles[i], 'playerDiv' + i);
            }
        }
    }
    if (typeof(test) != 'undefined') {
        if (test) {
            onExEndLoaded();
        } else {
            $('.caja').css('visibility', 'visible');
        }
    }
}



function createVideoDiv(videoNum) {
    var videoDiv = "<div style='display:block;margin:20px auto 20px auto;width:100%;clear:both;'> ";
    videoDiv += "<div id='playerDiv" + (videoNum) + "' style='display:block;margin:0 auto 0 auto;max-width:640px;width:100%' >";
    videoDiv += "Cargando v&iacute;deo...";
    videoDiv += "</div>";
    videoDiv += "</div>";
    return videoDiv;
}

function createAudioDiv(AudioUrl) {
    var audioDiv = "<p class='centrado'><audio id='sonido' src='" + AudioUrl + "' controls>";
    audioDiv += "<object data='/descargageneral.php?f=audios/dewplayer.swf' width='200' height='40' name='dewplayer' id='dewplayerjs' type='application/x-shockwave-flash'>";
    audioDiv += "<param name='movie' value='descargageneral.php?f=audios/dewplayer.swf' />";
    audioDiv += "<param name='flashvars' value='mp3=" + AudioUrl + "&javascript=on' />";
    audioDiv += "<param name='wmode' value='transparent' /></object>";
    audioDiv += "</audio></p>";
    return audioDiv;
}

function managePdfLinks() {
    $('.caja').find('.enlace').each(function(index) {
        $(this).on("click", function(e) {
            e.preventDefault();
            openPdf($(this).attr('href'))
        });
    });
}