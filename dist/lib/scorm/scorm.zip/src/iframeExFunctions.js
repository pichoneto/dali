// JavaScript Document

var totalIframeOkArr = new Array();
var exercisesInter = new Array();
var pregPos = 0;
var iframeExSaved = false;
var stepsTitlesArr = new Array();


showPreloader('Cargando v�deo');
for(i=0;i<pregFilesArr.length;i++){
	$('#step').append('<li class="step greySim rounded">'+(i+1)+'</li>');	
}

function manageVideoTest(){	
	addControl('##manageVideoTest : ' + videoTestObject);
	$('#videoProgress').hide();		
	if(videoTestObject){
		videoTestObject.addEventListener('timeupdate', function() {
			videoPos = Math.round(videoTestObject.currentTime);
			var videoDuration = Math.round(videoTestObject.duration);
			$('#time').html(videoPos +' de ' +videoDuration+ ' secs');
			var percent = (videoPos*100)/videoDuration;
			$('#percent').css({
				width : percent + '%'			  
			})				
			var nextStep = pregLaunchTime[pregPos];
			if(videoPos == nextStep){
				launchIframeEx(videoTestObject);
			}
		});		
		//videoTestObject.getControls().setEnabled(
   			// {all: false}).setWidgets({fullscreen: false})
	}else{
		//videoTestObject = flowplayer();
	}
			
	$(document).off('click', '#videoPlay').on('click', '#videoPlay',function() { 							 
				
		var dataState = $(this).attr('data-state');																 
		$('#videoProgress').show();				
		$('#VideoTest').css({visibility:'visible'})
				if(detectflash()){					
					if (flowplayer().isPaused()){
						startVideoProgressChecking();
						$(this).val('Pausar');
						flowplayer().currentTime+=1;
						flowplayer().play();
					}else{
						stopVideoProgressChecking();
						flowplayer().pause();
						$(this).val('Continuar');
					}					
				}else{					
					if(dataState){
						if (videoTestObject.paused) {
							videoTestObject.play();
							$(this).val('Pausar');
					   }else{
						  videoTestObject.pause();
						 $(this).val('Continuar');
					   }
					}else{
						 videoTestObject.play();
						$(this).attr('data-state',true);
						}
				}
			});
}




function launchIframeEx(me){
	me.pause();
	$('#videoPlay').val('Continuar');
	createExContainer(pregFilesArr[pregPos]);
	pregPos ++;
}



var videoExPop = 0;
function createExContainer(_file){	
				
	var ExContainer = '<div id="videoEx"><iframe id="iframeEx'+videoExPop+'" style="width:100%;height:100%;" frameborder="0" src=""></iframe></div>';
	var popup = '<div class="popEx" style="visibility:hidden"> <div class="popBar"><a class="popExClose" title="cerrar"><img src="../images/recursos/botClose.png" style="float:right;vertical-align:middle;cursor:pointer;" alt="cerrar"/></a></div> <div class="popExTxt">'+ExContainer+'</div></div>';
	$('body').append(popup);	
	showPreloader('Cargando ejercicio...');
	
	$('#iframeEx'+videoExPop).attr('src',_file);
	
	$(document).off('click', '.popExClose').on('click', '.popExClose',function() { 
		$('.popEx').hide();		
		if(typeof totalIframeOkArr[pregPos-1] == 'undefined'){			
			var titPaso = $('#iframeEx'+(videoExPop-1)).contents().find('h2').text()
			addArrayItem(3,'',titPaso);
		}
		if(pregPos == pregFilesArr.length){			
			$('.popEx').remove();
			endIframeEx(totalIframeOkArr);
		}else{
			hideObj($('#preloader'),true);
			}
	});	
	
	$('#iframeEx'+videoExPop).one('load', function() {
		addControl('IFRAME EX LOADED');
		showPreloader('Creando ejercicio...');
		videoExPop ++;
		centerDiv($('.popEx'));			
		$('.popExTxt').css({
			height:	$('.popEx').innerHeight() - $('.popBar').outerHeight()		 
		})
		$('#videoEx iframe').css({
			height:	$('.popExTxt').innerHeight()		 
		})
		
		$('#step li').removeClass('activeStep');
			var stepState = $('#step').find('li:eq('+(pregPos-1)+')');
			stepState.addClass('activeStep');
		})
}


function getIframeExOk(_arr){	
	var totalOk = 0;	
	for(i=0;i<_arr.length;i++){
		if(_arr[i]==1){
			totalOk++;
		}
	}	
	return totalOk;
}

function addArrayItem(val01,val02,tit){		
	totalIframeOkArr.push(val01);
	exercisesInter.push(val02);
	stepsTitlesArr.push(tit);
	
	var stepState = $('#step').find('li:eq('+(pregPos-1)+')');
	stepState.removeClass('greySim');
	stepState.removeClass('verdeoscuro');
	stepState.removeClass('rojo');
	stepState.removeClass('activeStep');	
	if(val01==1){
		stepState.addClass('verdeoscuro');
		}else{
			if(val02==""){
				stepState.addClass('greySim');
			}else{
				stepState.addClass('rojo');
			}
	}
}

function endIframeEx(Arr){
	var totalOk = getIframeExOk(Arr);
	var notaFinal = (totalOk*scoreMax)/pregFilesArr.length;
	saveData = true;
	showResultsList(totalIframeOkArr,notaFinal);
	try{
		grabaejercicio(notaFinal, exercisesInter.toString(),totalIframeOkArr.toString(),NotaCorte);
		
	}catch(e){		
		showError(ERROR_SAVE_EVAL)	
	}
	hideObj($('#preloader'),true);
	$('#videoDiv').hide();

}
